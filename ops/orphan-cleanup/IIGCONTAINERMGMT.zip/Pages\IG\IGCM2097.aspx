<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM2097.aspx.cs" Inherits="Page_IGCM2097" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.Graph.IGCMDutyTarrifAdjustmentMaint"
        PrimaryView="adjustment"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="adjustment" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector AutoRefresh="True" runat="server" ID="CstPXSelector2" DataField="Country" CommitChanges="True" ></px:PXSelector>
			<px:PXLayoutRule runat="server" ID="CstLayoutRule6" ColumnSpan="2" />
			<px:PXTextEdit runat="server" ID="CstPXTextEdit3" DataField="Descr" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" StartColumn="True" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox5" DataField="Active" CommitChanges="True" ></px:PXCheckBox></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab DataMember="details" ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem DependsOnView="adjustment" Text="Rates">
				<Template>
					<px:PXGrid Height="" Width="100%" DataSourceID="ds" AutoAdjustColumns="True" AllowPaging="True" AdjustPageSize="Auto" runat="server" ID="CstPXGrid7" SkinID="Details">
						<Levels>
							<px:PXGridLevel DataMember="details" >
								<Columns>
									<px:PXGridColumn DataField="CustomClassificationNbr" Width="120" CommitChanges="True" ></px:PXGridColumn>
									<px:PXGridColumn DataField="PercentageOfCost" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="FlatAmountPerUnit" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="FlatAmountPerWeight" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Tariff" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
						<AutoSize MinHeight="150" Enabled="True" Container="Parent" ></AutoSize>
						<AutoSize Enabled="True" ></AutoSize>
						<AutoSize MinHeight="150" ></AutoSize></px:PXGrid></Template>
			</px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
	</px:PXTab>
</asp:Content>
