﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3099.aspx.cs" Inherits="Pages_IGCM3099" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMINTransitRegisterEntry"
        PrimaryView="filter">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="iNDocuments" Visible="False" CommitChanges="True"></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Visible="False" Name="ViewPO" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Name="ViewInDocument" Visible="False" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Name="ViewContainer" Visible="False" CommitChanges="True" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Name="IGCMINTransitRegisterEntry_ShowSplits" Visible="False" DependOnGrid="grid" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Name="IGCMINTransitRegisterEntry_generateNumbers" Visible="False" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Name="SaveAllocations" CommitChanges="True" Visible="True" RepaintControls="All" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand DependOnGrid="grid" Name="register" CommitChanges="True" ></px:PXDSCallbackCommand></CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="filter" Width="100%" >
        <Template>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule3" StartRow="True" ></px:PXLayoutRule>
	<px:PXLayoutRule LabelsWidth="M" runat="server" ID="CstPXLayoutRule8" Merge="True" ></px:PXLayoutRule>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector12" DataField="LandedCostNbrStarting" ></px:PXSelector>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector11" DataField="LandedCostNbrEnding" ></px:PXSelector>
	<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox10" DataField="LandedCostAll" ></px:PXCheckBox>
	<px:PXLayoutRule runat="server" ID="CstLayoutRule9" ></px:PXLayoutRule>
	<px:PXLayoutRule LabelsWidth="M" runat="server" ID="CstPXLayoutRule13" Merge="True" ></px:PXLayoutRule>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector19" DataField="VendorIDStarting" ></px:PXSelector>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector18" DataField="VendorIDEnding" ></px:PXSelector>
	<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox17" DataField="VendorAll" ></px:PXCheckBox>
	<px:PXLayoutRule runat="server" ID="CstLayoutRule14" ></px:PXLayoutRule>
	<px:PXLayoutRule LabelsWidth="M" runat="server" ID="CstPXLayoutRule15" Merge="True" ></px:PXLayoutRule>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector21" DataField="PurchaseOrderNbrStarting" ></px:PXSelector>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector20" DataField="PurchaseOrderNbrEnding" ></px:PXSelector>
	<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox22" DataField="PurchaseOrdersAll" ></px:PXCheckBox>
	<px:PXLayoutRule runat="server" ID="CstLayoutRule16" ></px:PXLayoutRule>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartColumn="True" />
	<px:PXCheckBox runat="server" ID="CstPXCheckBox1" DataField="CreateAPBill" /></Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid AllowPaging="True" TabIndex="2" SyncPositionWithGraph="True" AutoAdjustColumns="True" NoteIndicator="False" FilesIndicator="False" SyncPosition="True" KeepPosition="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" SkinID="details" AllowAutoHide="false">
        <Levels>
            <px:PXGridLevel DataMember="Transactions">
<Columns>
	<px:PXGridColumn TextAlign="Center" CommitChanges="True" Type="CheckBox" AllowCheckAll="False" DataField="Selected" Width="60" ></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" LinkCommand="ViewContainer" DataField="LandedCostNbr" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="VendorID" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn LinkCommand="ViewPO" CommitChanges="True" DataField="PONbr" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ContainerQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InTransitQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InTransitSiteID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InTransitSiteLocation" Width="140" />
	<px:PXGridColumn DataField="QtyToInTransit" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel>
        </Levels>
        <ActionBar ActionsVisible="True">
            <Actions>
	<Delete ToolBarVisible="False" MenuVisible="False"></Delete>
	<AddNew MenuVisible="False" ToolBarVisible="False"></AddNew>
	<ExportExcel MenuVisible="False" ToolBarVisible="False"></ExportExcel>
	<ExportExcel MenuVisible="False" ToolBarVisible="False"></ExportExcel>
            </Actions>
        
	<CustomItems>
		<px:PXToolBarButton Key="cmdLS" Text="Line Details" CommandSourceID="ds" CommandName="IGCMINTransitLineSplittingExtension_ShowSplits" DependOnGrid="grid" ></px:PXToolBarButton>
		<px:PXToolBarSeperator ></px:PXToolBarSeperator>
		<px:PXToolBarButton Enabled="True" Tooltip="Inventory Transactions History" CommandName="" Visible="True" Text="IN History">
			<PopupCommand Command="" Enabled="" Target="" ></PopupCommand>
			<AutoCallBack Command="INDocuments" ></AutoCallBack>
			<AutoCallBack Enabled="True" ></AutoCallBack>
			<AutoCallBack Target="ds" ></AutoCallBack></px:PXToolBarButton></CustomItems></ActionBar>
	<AutoSize MinHeight="150" Enabled="True" Container="Window" ></AutoSize>
	<AutoSize Enabled="True" ></AutoSize></px:PXGrid>
	<px:PXSmartPanel Width="1000px" CaptionVisible="True" Caption="Inventory Transactions History" AcceptButtonID="CstButton26" runat="server" ID="CstSmartPanel23" Key="INDocumentsView" AutoReload="True" AutoRepaint="True" >
		<px:PXGrid SkinID="Inquire" ScrollBars="Auto" Width="100%" AllowPaging="True" SyncPositionWithGraph="True" KeepPosition="True" SyncPosition="True" FilesIndicator="False" NoteIndicator="False" Height="400" runat="server" ID="CstPXGrid24">
			<Levels>
				<px:PXGridLevel DataMember="LineINDocuments" >
					<Columns>
						<px:PXGridColumn DataField="TranType" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn LinkCommand="ViewInDocument" DataField="RefNbr" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="InventoryID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="TranDesc" Width="200" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SiteID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LocationID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LotSerialNbr" Width="200" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UOM" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="Qty" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UnitCost" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="TranCost" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="ExpireDate" Width="120" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
			<ContentLayout AutoSizeControls="True" ></ContentLayout></px:PXGrid>
		<px:PXPanel SkinID="Buttons" runat="server" ID="CstPanel25">
			<px:PXButton AlignLeft="False" runat="server" ID="CstButton26" DialogResult="OK" Text="Ok" ></px:PXButton></px:PXPanel></px:PXSmartPanel>
	<px:PXSmartPanel DesignView="Content" runat="server" ID="PanelLS" Height="360px" Width="764px" CaptionVisible="True" Caption="Line Details" Key="IGCMINTransitLineSplittingExtension_lsselect" AutoCallBack-Command="Refresh" AutoCallBack-Enabled="" AutoCallBack-Target="optform">
		<px:PXFormView runat="server" ID="optform" SkinID="Transparent" CaptionVisible="False" Width="100%" DataSourceID="ds" DataMember="IGCMINTransitLineSplittingExtension_LotSerOptions">
			<Template>
				<px:PXLayoutRule runat="server" ID="PXLayoutRule26" StartColumn="True" LabelsWidth="SM" ControlSize="XM" ></px:PXLayoutRule>
				<px:PXNumberEdit runat="server" Enabled="False" DataField="UnassignedQty" ID="edUnassignedQty" ></px:PXNumberEdit>
				<px:PXNumberEdit runat="server" DataField="Qty" ID="edQty">
					<AutoCallBack>
						<Behavior CommitChanges="True" ></Behavior></AutoCallBack></px:PXNumberEdit>
				<px:PXLayoutRule runat="server" ID="PXLayoutRule27" StartColumn="True" LabelsWidth="SM" ControlSize="XM" ></px:PXLayoutRule>
				<px:PXMaskEdit runat="server" DataField="StartNumVal" ID="edStartNumVal" ></px:PXMaskEdit>
				<px:PXButton runat="server" ID="btnGenerate" Text="Generate" CommandSourceID="ds" CommandName="IGCMINTransitLineSplittingExtension_generateNumbers" Height="20px" ></px:PXButton></Template>
			<Parameters>
				<px:PXSyncGridParam ControlID="grid" ></px:PXSyncGridParam></Parameters></px:PXFormView>
		<px:PXGrid SkinID="Details" KeepPosition="True" BatchUpdate="False" runat="server" ID="grid2" SyncPosition="true" Width="100%" AutoAdjustColumns="True" DataSourceID="ds" Style='left:0px;top:0px;height:192px;'>
			<AutoSize Enabled="true" ></AutoSize>
			<Mode InitNewRow="True" ></Mode>
			<Levels>
				<px:PXGridLevel DataKeyNames="LandedCostNbr,LineNbr,SplitLineNbr" DataMember="splits">
					<RowTemplate>
						<px:PXLayoutRule runat="server" ID="PXLayoutRule28" StartColumn="True" LabelsWidth="M" ControlSize="XM" ></px:PXLayoutRule>
						<px:PXSegmentMask runat="server" DataField="SubItemID" AutoRefresh="true" ID="edSubItemID2" ></px:PXSegmentMask>
						<px:PXSegmentMask runat="server" DataField="LocationID" AutoRefresh="true" ID="edLocationID2">
							<Parameters>
								<px:PXControlParam ControlID="grid2" PropertyName="DataValues[&quot;SiteID&quot;]" Name="IGCMPOLandedCostLine.siteID" Type="String" ></px:PXControlParam>
								<px:PXControlParam ControlID="grid2" PropertyName="DataValues[&quot;InventoryID&quot;]" Name="IGCMPOLandedCostLine.inventoryID" Type="String" ></px:PXControlParam>
								<px:PXControlParam ControlID="grid2" PropertyName="DataValues[&quot;SubItemID&quot;]" Name="IGCMPOLandedCostLine.subItemID" Type="String" ></px:PXControlParam></Parameters></px:PXSegmentMask>
						<px:PXNumberEdit runat="server" DataField="Qty" ID="edQty2" ></px:PXNumberEdit>
						<px:PXSelector runat="server" ID="edUOM2" DataField="UOM" AutoRefresh="true">
							<Parameters>
								<px:PXControlParam ControlID="grid" PropertyName="DataValues[&quot;InventoryID&quot;]" Name="IGCMPOLandedCostLine.inventoryID" Type="String" ></px:PXControlParam></Parameters></px:PXSelector>
						<px:PXSelector runat="server" ID="edLotSerialNbr2" DataField="LotSerialNbr" AutoRefresh="true">
							<Parameters>
								<px:PXControlParam ControlID="grid2" PropertyName="DataValues[&quot;InventoryID&quot;]" Name="IGCMPOLandedCostLine.inventoryID" Type="String" ></px:PXControlParam>
								<px:PXControlParam ControlID="grid2" PropertyName="DataValues[&quot;SubItemID&quot;]" Name="IGCMPOLandedCostLine.subItemID" Type="String" ></px:PXControlParam>
								<px:PXControlParam ControlID="grid2" PropertyName="DataValues[&quot;LocationID&quot;]" Name="IGCMPOLandedCostLine.locationID" Type="String" ></px:PXControlParam></Parameters></px:PXSelector>
						<px:PXDateTimeEdit runat="server" ID="edExpireDate2" DataField="ExpireDate" ></px:PXDateTimeEdit></RowTemplate>
					<Columns>
						<px:PXGridColumn DataField="InventoryID" Width="108px" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SubItemID" Width="108px" ></px:PXGridColumn>
						<px:PXGridColumn DataField="TransferSiteID" Width="140" ></px:PXGridColumn>
						<px:PXGridColumn DataField="TransferLocationID" Width="140" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LotSerialNbr" Width="108px" AllowShowHide="Server" ></px:PXGridColumn>
						<px:PXGridColumn DataField="Qty" TextAlign="Right" Width="108px" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UOM" Width="108px" ></px:PXGridColumn>
						<px:PXGridColumn DataField="ExpireDate" Width="90px" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
			<Parameters>
				<px:PXSyncGridParam ControlID="grid" ></px:PXSyncGridParam></Parameters></px:PXGrid>
		<px:PXPanel runat="server" ID="PXPanel2" SkinID="Buttons">
			<px:PXButton runat="server" ID="btnSave" Text="OK" DialogResult="OK" ></px:PXButton></px:PXPanel></px:PXSmartPanel>
	<px:PXSmartPanel Width="1000px" CaptionVisible="True" LoadOnDemand="True" Position="CenterWindow" AutoReload="True" AutoRepaint="True" runat="server" ID="CstSmartPanel29" Key="DistributionDialog" Caption="Lot/Serial Items Selection" >
		<px:PXGrid ScrollBars="Auto" Width="100%" SyncPosition="True" KeepPosition="True" ID="CstPXGrid30" DataSourceID="ds" Height="200" NoteIndicator="False" FilesIndicator="False" Caption="Lot/Serial Items requiring selection" CaptionVisible="True" runat="server" >
			<Levels>
				<px:PXGridLevel DataMember="LinesRequiringDistribution" >
					<Columns>
						<px:PXGridColumn DataField="LandedCostNbr" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="PONbr" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="InventoryID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SiteID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="ShippedQty" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="QtyToInTransit" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SplitsSelected" Width="100" ></px:PXGridColumn></Columns>
                                
					<RowTemplate>
						<px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit38" DataField="QtyToInTransit" ></px:PXNumberEdit></RowTemplate></px:PXGridLevel>
                        </Levels>
			<AutoCallBack Target="CstPXGrid31" Command="Refresh" Enabled="True" ></AutoCallBack>
                
			<ActionBar Position="Top" ActionsVisible="True">
				<Actions>
					<Refresh MenuVisible="True" ToolBarVisible="Top" Enabled="True" ></Refresh>
                                </Actions>
                        </ActionBar></px:PXGrid>
		<px:PXGrid ScrollBars="Auto" Width="100%" ID="CstPXGrid31" DataSourceID="ds" Height="200" Caption="Lot/Serial Item Allocation" CaptionVisible="True" NoteIndicator="False" FilesIndicator="False" runat="server">
			<Levels>
				<px:PXGridLevel DataMember="currentLineSplits" >
					<Columns>
						<px:PXGridColumn CommitChanges="True" Type="CheckBox" AllowCheckAll="True" DataField="Selected" Width="60" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LocationID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LotSerialNbr" Width="200" ></px:PXGridColumn>
						<px:PXGridColumn DataField="Qty" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UOM" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="ExpireDate" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="ReceiptedQty" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn CommitChanges="True" DataField="SelectedQty" Width="100" ></px:PXGridColumn></Columns>
                                
					<RowTemplate>
						<px:PXDateTimeEdit Enabled="False" runat="server" ID="CstPXDateTimeEdit39" DataField="ExpireDate" ></px:PXDateTimeEdit>
						<px:PXSegmentMask Enabled="False" runat="server" ID="CstPXSegmentMask40" DataField="LocationID" ></px:PXSegmentMask>
						<px:PXSelector Enabled="False" runat="server" ID="CstPXSelector41" DataField="LotSerialNbr" ></px:PXSelector>
						<px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit42" DataField="Qty" ></px:PXNumberEdit>
						<px:PXSelector Enabled="False" runat="server" ID="CstPXSelector43" DataField="UOM" ></px:PXSelector>
						<px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit46" DataField="ReceiptedQty" ></px:PXNumberEdit></RowTemplate></px:PXGridLevel>
                        </Levels>
			<ActionBar Position="Top" ActionsVisible="True">
			        <Actions>
				         <Refresh MenuVisible="True" ToolBarVisible="Top" Enabled="True" ></Refresh>
                                </Actions>
                        </ActionBar>
                </px:PXGrid>
		<px:PXPanel runat="server" ID="CstPanel32" SkinID="Buttons">
			<px:PXButton runat="server" ID="CstButton33" Text="Accept" DialogResult="OK" ></px:PXButton>
			<px:PXButton Text="Cancel" DialogResult="No" runat="server" ID="CstButton34" ></px:PXButton>
                </px:PXPanel></px:PXSmartPanel>
	<px:PXGrid runat="server" ID="PurchasesInTransitID">
		<Levels>
			<px:PXGridLevel ></px:PXGridLevel></Levels></px:PXGrid></asp:Content>