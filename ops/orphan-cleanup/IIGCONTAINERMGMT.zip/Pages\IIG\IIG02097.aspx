<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IIG02097.aspx.cs" Inherits="Page_IIG02097" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IIG.IIGRegistrationMaint"
        PrimaryView="DetailsView"
        >
    <CallbackCommands>
      <px:PXDSCallbackCommand Name="SaveRegistration" Visible="False" CommitChanges="True" ></px:PXDSCallbackCommand></CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
  <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="MasterView" Width="100%" Height="" AllowAutoHide="false">
    <Template>
      <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
      <px:PXLayoutRule LabelsWidth="M" runat="server" ID="CstPXLayoutRule4" StartColumn="True" ></px:PXLayoutRule>
      <px:PXTextEdit runat="server" ID="CstPXTextEdit1" DataField="CustomerName" ></px:PXTextEdit>
      <px:PXMaskEdit runat="server" ID="CstPXMaskEdit3" DataField="LicenseKey" ></px:PXMaskEdit>
      <px:PXMaskEdit runat="server" ID="CstPXMaskEdit2" DataField="InstallationID" ></px:PXMaskEdit>
      <px:PXLayoutRule runat="server" ID="CstPXLayoutRule5" StartColumn="True" ></px:PXLayoutRule>
      <px:PXTextEdit TextAlign="Center" Width="450px" Height="250px" TextMode="MultiLine" ForeColor="Red" runat="server" ID="CstPXTextEdit6" DataField="Reason" ></px:PXTextEdit></Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
  <px:PXGrid SyncPosition="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Details" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="DetailsView">
          <Columns>
	<px:PXGridColumn DataField="ProductDescr" Width="280" ></px:PXGridColumn>
        <px:PXGridColumn DataField="ReleaseLevel" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="ReleaseDate" Width="90" ></px:PXGridColumn>
        <px:PXGridColumn DataField="SerialNumber" Width="200" ></px:PXGridColumn>
        <px:PXGridColumn DataField="UnlockingKey" Width="350" ></px:PXGridColumn>
	<px:PXGridColumn Type="CheckBox" DataField="HasMaintenance" Width="60" ></px:PXGridColumn>
	<px:PXGridColumn Type="CheckBox" DataField="IsCustomization" Width="60" ></px:PXGridColumn>
	<px:PXGridColumn Type="CheckBox" DataField="ShowWarning" Width="60" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Status" Width="200" ></px:PXGridColumn>
	<px:PXGridColumn DataField="TransactionCount" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="RenewalDate" Width="90" /></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
    <ActionBar >
    
      <CustomItems>
        <px:PXToolBarButton Text="Save" DependOnGrid="grid">
          <AutoCallBack Command="SaveRegistration" Enabled="True" Target="ds" ></AutoCallBack></px:PXToolBarButton></CustomItems>
      <Actions>
        <Delete Enabled="False" ></Delete>
        <AddNew Enabled="False" ></AddNew></Actions></ActionBar>
  
	<AutoCallBack Command="Refresh" />
	<AutoCallBack Target="CstFeaturesGrid" /></px:PXGrid>
	<px:PXGrid Width="100%" runat="server" ID="CstFeaturesGrid" SkinID="Details">
		<Levels>
			<px:PXGridLevel DataMember="Features" >
				<Columns>
					<px:PXGridColumn DataField="FeatureDescr" Width="280" />
					<px:PXGridColumn Type="CheckBox" DataField="Enabled" Width="60" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
		<AutoSize Enabled="True" ></AutoSize>
		<AutoSize MinHeight="150" ></AutoSize>
		<ActionBar>
			<Actions>
				<AddNew Enabled="False" ></AddNew></Actions></ActionBar>
		<ActionBar>
			<Actions>
				<Delete Enabled="False" ></Delete></Actions></ActionBar>
		<ActionBar>
			<Actions>
				<Delete ToolBarVisible="False" ></Delete></Actions></ActionBar>
		<ActionBar>
			<Actions>
				<AddNew ToolBarVisible="False" ></AddNew></Actions></ActionBar></px:PXGrid>
  <px:PXUploadDialog runat="server" AllowedFileTypes=".iigkey" RenderCheckIn="false" RenderComment="false" RenderLink="false" RenderLinkTextBox="false" AutoSaveFile="false" SessionKey="UploadedLicenseKey" Height="60px" Width="400px" ID="dlgUploadFile" Caption="Upload New License File" Key="UploadDialogPanel" Style='Position:static;' ></px:PXUploadDialog>
  <px:PXSmartPanel runat="server" ID="pnlNewLicense" ForeColor="Black" LoadOnDemand="true" CaptionVisible="True" Caption="Activate New License" Key="LicenseKeyPanel" Style='Position:static;'>
    <px:PXFormView runat="server" Width="100%" ID="frmInstall" DataSourceID="ds">
      <Template>
        <px:PXPanel runat="server" ID="PXPanel1" SkinID="Buttons">
          <px:PXButton runat="server" ID="PXUploadPanelButton1" Text="OK" DialogResult="OK" ></px:PXButton>
          <px:PXButton runat="server" ID="PXUploadPanelButton2" Text="Cancel" DialogResult="Cancel" ></px:PXButton></px:PXPanel></Template></px:PXFormView></px:PXSmartPanel>
	<px:PXSmartPanel runat="server" ID="CstSmartPanel1" Caption="Confirmation Password" Key="checkConfirmationPassword" >
		<px:PXFormView runat="server" ID="CstFormView2" DataMember="checkConfirmationPassword">
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule3" StartRow="True" ></px:PXLayoutRule>
				<px:PXTextEdit TextMode="Password" CommitChanges="True" runat="server" ID="CstPXTextEdit4" DataField="Password" ></px:PXTextEdit></Template></px:PXFormView>
		<px:PXPanel runat="server" ID="CstPanel5">
			<px:PXButton runat="server" ID="CstButton6" DialogResult="OK" Text="OK" ></px:PXButton>
			<px:PXButton runat="server" ID="CstButton7" DialogResult="Cancel" Text="Cancel" ></px:PXButton></px:PXPanel></px:PXSmartPanel>
	<px:PXSmartPanel runat="server" ID="CstSmartPanel8" Key="extendDemoLicense" Caption="Extend Demo License" >
		<px:PXFormView runat="server" ID="CstFormView9" DataMember="extendDemoLicense">
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule13" StartRow="True" ></px:PXLayoutRule>
				<px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit15" DataField="ProductCode" ></px:PXTextEdit>
				<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit14" DataField="NewExpirationDate" ></px:PXDateTimeEdit></Template></px:PXFormView>
		<px:PXPanel runat="server" ID="CstPanel10">
			<px:PXButton DialogResult="OK" Text="OK" runat="server" ID="CstButton11" ></px:PXButton>
			<px:PXButton DialogResult="Cancel" Text="Cancel" runat="server" ID="CstButton12" ></px:PXButton></px:PXPanel></px:PXSmartPanel></asp:Content>