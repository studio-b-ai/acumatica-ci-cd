<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3097.aspx.cs" Inherits="Page_IGCM3097" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMPOLCTallyEntry"
        PrimaryView="LandedCosts"
        >
    <CallbackCommands>
      <px:PXDSCallbackCommand Name="ClearTallyQuantities" CommitChanges="True" Visible="False" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Name="CompleteShipped" Visible="False" /></CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
  <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="LandedCosts" Width="100%" Height="" AllowAutoHide="false">
    <Template>
      <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
      <px:PXSelector runat="server" ID="CstPXSelector2" DataField="LandedCostNbr" ></px:PXSelector>
      <px:PXButton Visible="False" runat="server" ID="ClearTallyQuantities" ></px:PXButton></Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
  <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Details" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="LandedCostLines">
          <Columns>
        <px:PXGridColumn AllowUpdate="False" DataField="PONbr" Width="70" ></px:PXGridColumn>
        <px:PXGridColumn AllowUpdate="False" DataField="InventoryID" Width="90" ></px:PXGridColumn>
	<px:PXGridColumn DataField="UPCCode" Width="120" ></px:PXGridColumn>
        <px:PXGridColumn AllowUpdate="False" DataField="Descr" Width="200" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OrderQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ContainerQty" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn CommitChanges="True" DataField="TallyQty" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn CommitChanges="True" AllowUpdate="False" DataField="UOM" Width="70" ></px:PXGridColumn></Columns>
      
	<RowTemplate>
		<px:PXSelector CommitChanges="True" AutoRefresh="True" runat="server" ID="CstPXSelector1" DataField="UOM" ></px:PXSelector></RowTemplate></px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
  
    <ActionBar>
      <CustomItems>
        <px:PXToolBarButton Text="Clear Tally Quantities" DependOnGrid="" Enabled="True" CommandName="" >
          <AutoCallBack Target="ds" Enabled="True" Command="ClearTallyQuantities" ></AutoCallBack>
          <AutoCallBack Enabled="True" ></AutoCallBack>
          <AutoCallBack Target="ds" ></AutoCallBack></px:PXToolBarButton>
	<px:PXToolBarButton Text="Complete Shipped" Enabled="True">
		<AutoCallBack Command="CompleteShipped" Enabled="True" Target="ds" /></px:PXToolBarButton></CustomItems>
        <Actions>
          <AddNew ToolBarVisible="False" ></AddNew>
          <Delete ToolBarVisible="False" ></Delete></Actions></ActionBar></px:PXGrid>
</asp:Content>