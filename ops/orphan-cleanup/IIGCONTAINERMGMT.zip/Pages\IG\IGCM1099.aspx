<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM1099.aspx.cs" Inherits="Page_IGTS1099" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.Graph.IGCMCustomClassificationForOriginDestinationCountryMaint"
        PrimaryView="Records"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Records">
			    <Columns>
				<px:PXGridColumn CommitChanges="True" DataField="InventoryID" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="OriginCountry" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="DestinationCountry" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomClassificationNbr" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Descr" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="PercentageOfCost" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="FlatAmountPerUnit" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="FlatAmountPerWeight" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="Tariff" Width="100" ></px:PXGridColumn></Columns>
			
				<RowTemplate>
					<px:PXSelector runat="server" ID="CstPXSelector1" DataField="CustomClassificationNbr" AutoRefresh="True" ></px:PXSelector></RowTemplate></px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		
			<Actions>
				<Upload Enabled="True" ></Upload></Actions></ActionBar>
	
		<Mode InitNewRow="True" AllowUpload="True" ></Mode></px:PXGrid>
</asp:Content>