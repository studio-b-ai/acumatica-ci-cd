<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM2092.aspx.cs" Inherits="Page_IGCM2092" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMContainerTypeMaint"
        PrimaryView="ContainerType"
        >
    <CallbackCommands>

    </CallbackCommands>
  </px:PXDataSource></asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
  <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" HeIGCMht="150px" SkinID="Primary" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="ContainerType">
          <Columns>
        <px:PXGridColumn CommitChanges="True" DataField="ContainerTypeID" Width="120" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Descr" Width="200" ></px:PXGridColumn>
	<px:PXGridColumn DataField="Volume" Width="100" />
	<px:PXGridColumn DataField="UOM" Width="72" /></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    <ActionBar >
    </ActionBar>
  </px:PXGrid>
</asp:Content>