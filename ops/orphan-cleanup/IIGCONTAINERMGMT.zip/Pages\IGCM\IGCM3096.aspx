<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3096.aspx.cs" Inherits="Page_IGCM3096" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMPOLCDistributionEntry"
        PrimaryView="Documents"
        >
    <CallbackCommands>
      <px:PXDSCallbackCommand CommitChanges="True" Visible="False" Name="AddLandedCosts" ></px:PXDSCallbackCommand>
      <px:PXDSCallbackCommand Name="viewLandedCost" Visible="False" CommitChanges="True" ></px:PXDSCallbackCommand>
      <px:PXDSCallbackCommand CommitChanges="True" Name="viewLandedCostCode" Visible="False" ></px:PXDSCallbackCommand></CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
  <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Documents" Width="100%" Height="" AllowAutoHide="false">
    <Template>
      <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
      <px:PXLayoutRule runat="server" ID="CstPXLayoutRule5" StartColumn="True" ></px:PXLayoutRule>
      <px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector52" DataField="FileNbr" ></px:PXSelector>
      <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit51" DataField="FileDate" ></px:PXDateTimeEdit>
      <px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector23" DataField="VendorID" ></px:PXSelector>
      <px:PXLayoutRule GroupCaption="Totals" runat="server" ID="CstPXLayoutRule6" StartColumn="True" ></px:PXLayoutRule>
      <px:PXNumberEdit runat="server" ID="CstPXNumberEdit92" DataField="TotalQuantity" ></px:PXNumberEdit>
      <px:PXNumberEdit runat="server" ID="CstPXNumberEdit91" DataField="TotalCost" ></px:PXNumberEdit>
      <px:PXNumberEdit runat="server" ID="CstPXNumberEdit50" DataField="TotalWeight" ></px:PXNumberEdit>
      <px:PXNumberEdit runat="server" ID="CstPXNumberEdit49" DataField="TotalVolume" ></px:PXNumberEdit></Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
  <px:PXTab DataMember="CurrentDocument" ID="tab" runat="server" Width="100%" HeIGCMht="150px" DataSourceID="ds" AllowAutoHide="false">
    <Items>
      <px:PXTabItem Text="Document Details">
        <Template>
          <px:PXGrid SyncPosition="True" AdjustPageSize="Auto" Width="100%" SkinID="DetailsInTab" runat="server" ID="detailsGrid">
            <Levels>
              <px:PXGridLevel DataMember="DistributionsDetails" >
                <Columns>
                  <px:PXGridColumn LinkCommand="viewLandedCost" CommitChanges="True" DataField="LandedCostNbr" Width="120" ></px:PXGridColumn></Columns>
                <RowTemplate>
                  <px:PXSelector runat="server" ID="CstPXSelector53" DataField="LandedCostNbr" AutoRefresh="True" ></px:PXSelector></RowTemplate></px:PXGridLevel></Levels>
            <AutoSize Enabled="True" ></AutoSize>
            <AutoSize Container="Parent" ></AutoSize>
            <ActionBar>
              <CustomItems>
                <px:PXToolBarButton Tooltip="Add Multiple Containers" Text="Add Containers" CommandName="" >
                  <AutoCallBack Command="AddLandedCosts" ></AutoCallBack>
                  <AutoCallBack Enabled="True" ></AutoCallBack>
                  <AutoCallBack Target="ds" ></AutoCallBack></px:PXToolBarButton></CustomItems></ActionBar></px:PXGrid></Template>
      </px:PXTabItem>
      <px:PXTabItem Text="Vendor Info" >
        <Template>
          <px:PXLayoutRule runat="server" ID="CstPXLayoutRule27" StartGroup="True" GroupCaption="Vendor Address" ></px:PXLayoutRule>
          <px:PXFormView CaptionVisible="False" RenderStyle="Simple" DataMember="Remit_Contact" runat="server" ID="CstFormView28" >
            <Template>
              <px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule47" StartColumn="True" ></px:PXLayoutRule>
              <px:PXTextEdit  runat="server" ID="CstPXTextEdit31" DataField="FullName" ></px:PXTextEdit>
              <px:PXTextEdit runat="server" ID="CstPXTextEdit34" DataField="Salutation" ></px:PXTextEdit>
              <px:PXTextEdit runat="server" ID="CstPXTextEdit33" DataField="Phone1" ></px:PXTextEdit>
              <px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit30" DataField="Email" ></px:PXTextEdit></Template></px:PXFormView>
          <px:PXFormView RenderStyle="Simple" CaptionVisible="False" DataMember="Remit_Address" runat="server" ID="CstFormView29" >
            <Template>
              <px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" StartColumn="True" runat="server" ID="CstLayoutRule45" ></px:PXLayoutRule>
              <px:PXTextEdit runat="server" ID="CstPXTextEdit35" DataField="AddressLine1" ></px:PXTextEdit>
              <px:PXTextEdit runat="server" ID="CstPXTextEdit36" DataField="AddressLine2" ></px:PXTextEdit>
              <px:PXTextEdit runat="server" ID="CstPXTextEdit37" DataField="City" ></px:PXTextEdit>
              <px:PXSelector runat="server" ID="CstPXSelector38" DataField="CountryID" ></px:PXSelector>
              <px:PXSelector runat="server" ID="CstPXSelector42" DataField="State" ></px:PXSelector>
              <px:PXTextEdit runat="server" ID="CstPXTextEdit41" DataField="PostalCode" ></px:PXTextEdit></Template></px:PXFormView></Template></px:PXTabItem>
      <px:PXTabItem Text="Dates">
  <Template>
    <px:PXLayoutRule ColumnWidth="" LabelsWidth="XM" runat="server" ID="CstPXLayoutRule41" StartColumn="True"></px:PXLayoutRule>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit43" DataField="ExpectedDepartureDate"></px:PXDateTimeEdit>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit42" DataField="ExpectedArrivalDate"></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit25" DataField="FactoryReadyDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit31" DataField="UsrIGCMFactoryPickupDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit34" DataField="UsrIGCMOnBoardDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit29" DataField="UsrIGCMContainerLoadingDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit28" DataField="UsrIGCMCargoReadyDate" ></px:PXDateTimeEdit>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit44" DataField="PaymentDueDate"></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit15" DataField="ShipmentWindowStartDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit14" DataField="ShipmentWindowEndDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit26" DataField="GCCDate" ></px:PXDateTimeEdit>
    <px:PXLayoutRule ColumnWidth="" LabelsWidth="XM" runat="server" ID="CstPXLayoutRule18" StartColumn="True"></px:PXLayoutRule>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit46" DataField="ActualDepartureDate"></px:PXDateTimeEdit>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit45" DataField="ActualArrivalDate"></px:PXDateTimeEdit>
    <px:PXTextEdit runat="server" ID="CstPXTextEdit51" DataField="CustomsEntryNbr"></px:PXTextEdit>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit50" DataField="CustomsEntryDate"></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit30" DataField="UsrIGCMExpCustomsClearanceDate" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit23" DataField="DrayageAppointmentDate_Date" ></px:PXDateTimeEdit>
  <px:PXDateTimeEdit TimeMode="True" runat="server" ID="CstPXDateTimeEdit24" DataField="DrayageAppointmentDate_Time" ></px:PXDateTimeEdit>
    <px:PXLayoutRule ColumnWidth="" LabelsWidth="XM" runat="server" ID="CstPXLayoutRule19" StartColumn="True"></px:PXLayoutRule>
    <px:PXTextEdit runat="server" ID="CstPXTextEdit47" DataField="DeliveryOrderNbr"></px:PXTextEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit1" DataField="DeliveryOrderDate" />
  <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit32" DataField="UsrIGCMFinalDeliveryDate" ></px:PXDateTimeEdit>
    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit49" DataField="LastFreeDate"></px:PXDateTimeEdit>
    <px:PXTextEdit runat="server" ID="CstPXTextEdit52" DataField="BrokerInvoiceNbr"></px:PXTextEdit>
  <px:PXTextEdit runat="server" ID="CstPXTextEdit11" DataField="MainReferenceInvoice" ></px:PXTextEdit>
  <px:PXTextEdit runat="server" ID="CstPXTextEdit12" DataField="SecondaryInvoice" ></px:PXTextEdit>
  <px:PXTextEdit runat="server" ID="CstPXTextEdit16" DataField="UsrIGCMBillOfLadingNumber" ></px:PXTextEdit>
  <px:PXNumberEdit runat="server" ID="CstPXNumberEdit13" DataField="EstimatedFreight" ></px:PXNumberEdit></Template>
    </px:PXTabItem>
      <px:PXTabItem Text="Landed Costs" >
        <Template>
          <px:PXGrid SyncPosition="True" Width="100%" SkinID="Details" AdjustPageSize="Auto" runat="server" ID="lcGrid">
            <Levels>
              <px:PXGridLevel DataMember="LandedCosts" >
                <Columns>
                  <px:PXGridColumn LinkCommand="viewLandedCostCode" CommitChanges="True" DataField="LandedCostCodeID" Width="120" ></px:PXGridColumn>
                  <px:PXGridColumn DataField="LandedCostCode__Descr" Width="200" ></px:PXGridColumn>
                  <px:PXGridColumn CommitChanges="True" DataField="DollarsPayable" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InvoiceNbr" Width="180" />
	<px:PXGridColumn CommitChanges="True" DataField="VendorID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="VendorLocationID" Width="70" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
            <AutoSize Enabled="True" ></AutoSize>
            <AutoSize Container="Parent" ></AutoSize></px:PXGrid></Template></px:PXTabItem></Items>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
  </px:PXTab>
  <px:PXSmartPanel AutoRepaint="True" CallBackMode-CommitChanges="True" AutoCallBack-Behavior-CommitChanges="True" AutoSaveChanges="True" AutoReload="True" Key="OpenLandedCosts" Caption="Add Containers" CaptionVisible="True" runat="server" ID="CstSmartPanel83">
    <px:PXGrid AdjustPageSize="Auto" SkinID="Inquire" AutoRepaint="True" runat="server" ID="CstPXGrid84">
      <Levels>
        <px:PXGridLevel DataMember="OpenLandedCosts" >
          <Columns>
            <px:PXGridColumn TextAlign="Center" AllowCheckAll="True" DataField="Selected" Width="30" Type="CheckBox" ></px:PXGridColumn>
            <px:PXGridColumn DataField="LandedCostNbr" Width="120" ></px:PXGridColumn>
            <px:PXGridColumn DataField="LandedCostDate" Width="120" ></px:PXGridColumn>
            <px:PXGridColumn DataField="OrderQty" Width="100" ></px:PXGridColumn>
            <px:PXGridColumn DataField="TotalAmount" Width="100" ></px:PXGridColumn>
            <px:PXGridColumn DataField="TotalVolume" Width="100" ></px:PXGridColumn>
            <px:PXGridColumn DataField="TotalWeight" Width="100" ></px:PXGridColumn>
            <px:PXGridColumn DataField="Status" Width="80" ></px:PXGridColumn></Columns>
          <RowTemplate>
<px:PXCheckBox ID="Selected" runat="server" DataField="Selected" AutoRefresh="True"></px:PXCheckBox></RowTemplate></px:PXGridLevel></Levels>
      <AutoSize Enabled="True" ></AutoSize>
      <AutoSize MinHeight="240" ></AutoSize>
      <CallbackCommands>
        <Refresh CommitChanges="True" ></Refresh></CallbackCommands>
      <OnChangeCommand>
        <Behavior CommitChanges="True" ></Behavior></OnChangeCommand>
      <AutoCallBack>
        <Behavior CommitChanges="True" ></Behavior></AutoCallBack></px:PXGrid>
    <px:PXPanel SkinID="Buttons" runat="server" ID="CstPanel85">
      <px:PXButton SyncVisible="False" runat="server" ID="CstButton1" Text="Add">
        <AutoCallBack Command="AddLandedCosts2" Target="ds" ></AutoCallBack></px:PXButton>
      <px:PXButton DialogResult="OK" Text="Add &amp; Close" runat="server" ID="CstButton86" ></px:PXButton>
      <px:PXButton Text="Cancel" DialogResult="Cancel" runat="server" ID="CstButton87" ></px:PXButton></px:PXPanel></px:PXSmartPanel></asp:Content>