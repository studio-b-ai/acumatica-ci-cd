<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM2094.aspx.cs" Inherits="Page_IGCM2094" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMContainerDestinationMaint"
        PrimaryView="ContainerDestination"
        >
    <CallbackCommands>

    </CallbackCommands>
  </px:PXDataSource></asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
  <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" HeIGCMht="150px" SkinID="Primary" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="ContainerDestination">
          <Columns>
        <px:PXGridColumn DataField="DestinationCodeID" Width="120" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Descr" Width="200" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    <ActionBar >
    </ActionBar>
  </px:PXGrid>
</asp:Content>