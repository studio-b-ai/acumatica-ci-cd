<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM1010.aspx.cs" Inherits="Page_IGCM1010" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMSetupMaint"
        PrimaryView="setup"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server"></asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab DataMember="setup" ID="IGCMSetupTab" runat="server" Width="100%" Height="487px" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="General">
				<Template>
					<px:PXLayoutRule LabelsWidth="L" runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule5" StartGroup="True" GroupCaption="Container Tracking Options" ></px:PXLayoutRule>
					<px:PXSelector AutoRefresh="True" AllowEdit="True" runat="server" ID="CstPXSelector9" DataField="LandedCostNumberingID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" AllowEdit="True" runat="server" ID="CstPXSelector10" DataField="LCDistributionNumberingID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" AllowEdit="True" runat="server" ID="CstPXSelector11" DataField="ShippingContainerNumberingID" ></px:PXSelector>
					<px:PXDropDown CommitChanges="True" runat="server" ID="CstPXDropDown13" DataField="UpdatePOPromDate" ></px:PXDropDown>
					<px:PXDropDown CommitChanges="True" runat="server" ID="CstPXDropDown14" DataField="UpdatePOReqDate" ></px:PXDropDown>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector12" DataField="UPCCodeAttribute" ></px:PXSelector>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox25" DataField="ShippedQtyExceed" ></px:PXCheckBox>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox8" DataField="AllowZeroCharge" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox34" DataField="CopyNotesAndAttachments" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox1" DataField="GroupPOReceiptByBranch" ></px:PXCheckBox>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule6" StartGroup="True" GroupCaption="Duty/Tariff Calculation" ></px:PXLayoutRule>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox16" DataField="AutoAllocateLandedCost" ></px:PXCheckBox>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox18" DataField="GSPEligible" ></px:PXCheckBox>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox15" DataField="AdvancedDutyCalculation" ></px:PXCheckBox>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector17" DataField="DutyLandedCostCodeID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector19" DataField="TariffLandedCostCodeID" ></px:PXSelector>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule7" StartGroup="True" GroupCaption="IN-Transit Processing" ></px:PXLayoutRule>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox21" DataField="AllowInTransitProcessing" ></px:PXCheckBox>
					<px:PXSegmentMask AllowEdit="True" AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSegmentMask22" DataField="DefaultInTransitSiteID" ></px:PXSegmentMask>
					<px:PXSelector AllowEdit="True" AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector31" DataField="AdjustmentReasonCode" ></px:PXSelector>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox26" DataField="CreateAdjustment" ></px:PXCheckBox>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox33" DataField="AutoCreateAPBill" ></px:PXCheckBox>
					<px:PXCheckBox runat="server" ID="CstPXCheckBox32" DataField="AutoReleaseAPBill" ></px:PXCheckBox>
                                        <px:PXCheckBox runat="server" ID="CstPXCheckBox51" DataField="LocationInTransit" ></px:PXCheckBox>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox2" DataField="GenerateTemporarySerialNumber" ></px:PXCheckBox>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit1" DataField="TemporarySerialNumberPrefix" />
					<px:PXLayoutRule GroupCaption="Container Management Enable/Disable" LabelsWidth="" runat="server" ID="CstPXLayoutRule3" StartGroup="True" ></px:PXLayoutRule>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox27" DataField="ContainerManagementEnabled" ></px:PXCheckBox>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartColumn="True" LabelsWidth="SM" ></px:PXLayoutRule>
                                        <px:PXLayoutRule runat="server" ID="CstExpeditorsPassword" StartGroup="True" GroupCaption="Searates information" ></px:PXLayoutRule>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit28" DataField="SearateAPIKey" TextMode="Password"></px:PXTextEdit>
					<px:PXDropDown runat="server" ID="CstPXDropDown1" DataField="SearateUpdateUsing" ></px:PXDropDown>
					<px:PXLayoutRule GroupCaption="Vessel finder" runat="server" ID="CstPXLayoutRule29" StartGroup="True" ></px:PXLayoutRule>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit30" DataField="VesselFinderAPIKey" TextMode="Password"></px:PXTextEdit>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" StartGroup="True" GroupCaption="Expeditors information" ></px:PXLayoutRule>
					<px:PXTextEdit runat="server" ID="IGCMExpeditorsClientID" DataField="ExpeditorsClientID" ></px:PXTextEdit>
					<px:PXTextEdit TextMode="Password" runat="server" ID="IGCMExpeditorsPasswordID" DataField="ExpeditorsPassword" ></px:PXTextEdit></Template>
			</px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
	</px:PXTab>
</asp:Content>