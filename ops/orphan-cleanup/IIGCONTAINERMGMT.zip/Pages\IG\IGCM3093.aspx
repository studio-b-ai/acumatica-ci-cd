<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3093.aspx.cs" Inherits="Page_IGCM3093" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMCustomClassificationMaint"
        PrimaryView="CustomClassification"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">

					<px:PXGrid AllowPaging="True" KeepPosition="True" SyncPosition="True" Enabled="False" Height="" SkinID="Primary" Width="100%" runat="server" ID="CstPXGrid7">
						<Levels>
							<px:PXGridLevel DataMember="CustomClassification" >
								<Columns>
									<px:PXGridColumn CommitChanges="True" Required="True" DataField="CustomClassificationNbr" Width="120" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Descr" Width="180" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="PercentageOfCost" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="FlatAmountPerUnit" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="FlatAmountPerWeight" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
						<AutoSize Container="Window" MinHeight="150" Enabled="True" ></AutoSize>
						<AutoCallBack Target="CstPXGrid16" Enabled="True" Command="Refresh" ></AutoCallBack>
						<ActionBar>
							<Actions>
								<Delete Enabled="True" ></Delete>
								<AddNew ToolBarVisible="False" MenuVisible="False" Enabled="True" ></AddNew>
								<AddNew MenuVisible="True" ></AddNew>
								</Actions></ActionBar>
						<ActionBar>
							<Actions>
								<Delete MenuVisible="True" ></Delete></Actions></ActionBar></px:PXGrid>
	<px:PXGrid AllowPaging="True" runat="server" ID="CstPXGrid16" SkinID="Inquire" Width="100%">
		<Levels>
			<px:PXGridLevel DataMember="Tariff" >
				<Columns>
					<px:PXGridColumn DataField="CountryCode" Width="70" ></px:PXGridColumn>
					<px:PXGridColumn CommitChanges="True" DataField="Tariff" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar>
			<Actions>
				<AddNew MenuVisible="True" ></AddNew>
				</Actions></ActionBar>
		<ActionBar>
			<Actions>
				<AddNew Enabled="True" ></AddNew></Actions></ActionBar>
		<ActionBar>
			<Actions>
				<Delete Enabled="True" ></Delete></Actions></ActionBar>
		<ActionBar>
			<Actions>
				<Delete MenuVisible="True" ></Delete></Actions></ActionBar></px:PXGrid></asp:Content>