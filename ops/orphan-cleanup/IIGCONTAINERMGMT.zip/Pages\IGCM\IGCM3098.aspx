<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3098.aspx.cs" Inherits="Page_IGCM3098" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true"  runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMPOLandedCostEntry"
        PrimaryView="IIGDocument">
        <CallbackCommands>
            <px:PXDSCallbackCommand CommitChanges="True" Name="poLinesSelection" Visible="False"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand CommitChanges="True" Visible="False" Name="openOrders"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand CommitChanges="True" Name="AddPOOrderLine" Visible="False"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand CommitChanges="True" Name="AddPOOrderLine2" Visible="False"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand CommitChanges="True" Name="ViewPOOrder" Visible="False"></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Name="ViewInDocument" Visible="False" ></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddPOOrder" Visible="False"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand  CommitChanges="True" DependOnGrid="grid" Name="OverrideTallyQty" Visible="False"></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand CommitChanges="True" Name="INDocuments" Visible="False" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="updateVesselInfo" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand  Name="openForwarderSite" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="showVesselLocation" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False"  CommitChanges="True" Name="addSOTransfer2" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="importPoContainer" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="showContainerInfo" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="showShipmentInfo" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="updateExpeditorInfo" ></px:PXDSCallbackCommand>
	<px:PXDSCallbackCommand Visible="False" Name="clearExpeditorInfo" ></px:PXDSCallbackCommand></CallbackCommands>
    
	<ClientEvents CommandPerformed="FormView_Load"  ></ClientEvents></px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView NoteIndicator="True" ActivityIndicator="True" Caption="Document Summary" ID="form" runat="server" DataSourceID="ds" DataMember="IIGDocument" Width="100%" AllowAutoHide="false">
        <Template>
            <px:PXLayoutRule ColumnWidth="L" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule2" StartColumn="True"></px:PXLayoutRule>
            <px:PXSelector runat="server" ID="CstPXSelector6" DataField="LandedCostNbr"></px:PXSelector>
            <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit5" DataField="LandedCostDate"></px:PXDateTimeEdit>
            <px:PXDropDown runat="server" ID="CstPXDropDown38" DataField="Status"></px:PXDropDown>
            <px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector39" DataField="ContainerStatusID"></px:PXSelector>
	<px:PXSelector runat="server" ID="CstPXSelector4" DataField="SearateStatusID" ></px:PXSelector>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector5" DataField="CountryCode" ></px:PXSelector>
            <px:PXCheckBox CommitChanges="True" runat="server" ID="chkHold" DataField="Hold"></px:PXCheckBox>
	<px:PXCheckBox runat="server" ID="CstPXCheckBox3" DataField="UsrIGCMAutoAllocateLandedCost" ></px:PXCheckBox>
	<px:PXTextEdit EnableClientScript="True" CommitChanges="True" runat="server" ID="CstPXTextEdit26" DataField="MMSI" >
  <ClientEvents ValueChanged="loadData" Initialize="loadData" ></ClientEvents></px:PXTextEdit>
	<px:PXLayoutRule runat="server" ID="CstLayoutRule24" ColumnSpan="2" ></px:PXLayoutRule>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit19" DataField="Descr" ></px:PXTextEdit>
	<px:PXJavaScript runat="server" ID="CstChangeTotalVolumeColor" IsStartupScript="True" Script="function FormView_Load() {     if(px_all[ &#39;ctl00_phF_form_t0_CstPXNumberEdit14&#39;].getValue() != null &amp;&amp; px_all[ &#39;ctl00_phF_form_t0_CstPXNumberEdit107&#39;].getValue() != null)  {   if(100*px_all[ &#39;ctl00_phF_form_t0_CstPXNumberEdit14&#39;].getValue()/px_all[ &#39;ctl00_phF_form_t0_CstPXNumberEdit107&#39;].getValue() >= 100)  { ctl00_phF_form_t0_CstPXNumberEdit14.style.color = &#39;red&#39;; }    else if( 100*px_all[ &#39;ctl00_phF_form_t0_CstPXNumberEdit14&#39;].getValue()/px_all[ &#39;ctl00_phF_form_t0_CstPXNumberEdit107&#39;].getValue() >= 90)  { ctl00_phF_form_t0_CstPXNumberEdit14.style.color = &#39;#4531fe&#39;; }    else { ctl00_phF_form_t0_CstPXNumberEdit14.style.color = null;} }  else { ctl00_phF_form_t0_CstPXNumberEdit14.style.color = null;} return; }" ></px:PXJavaScript>
	<px:PXLayoutRule ColumnWidth="L" LabelsWidth="SM" runat="server" ID="CstLayoutRule4" StartColumn="True" ></px:PXLayoutRule>
            <px:PXSegmentMask CommitChanges="True" runat="server" ID="CstPXSegmentMask9" DataField="VendorID"></px:PXSegmentMask>
	<px:PXSegmentMask CommitChanges="True" AutoRefresh="True" runat="server" ID="CstPXSegmentMask1" DataField="VendorLocationID" ></px:PXSegmentMask>
            <px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit54" DataField="ContainerNbr"></px:PXTextEdit>
	<px:PXSelector runat="server" ID="CstPXFreightForwarder" DataField="UsrIGCMFreightForwarderID" ></px:PXSelector>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector10" DataField="ContainerTypeID" ></px:PXSelector>
	<px:PXSelector runat="server" ID="CstPXSelector9" DataField="LogisticsServiceID" ></px:PXSelector>
	<px:PXSelector runat="server" ID="CstPXSelector8" DataField="DestinationCodeID" ></px:PXSelector>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector1" DataField="InTransitLocation" ></px:PXSelector>
	<px:PXLayoutRule ColumnWidth="XL" runat="server" ID="CstPXLayoutRule5" StartColumn="True" ></px:PXLayoutRule>
            <px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit30" DataField="OrderQty"></px:PXNumberEdit>
            <px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit53" DataField="TotalAmount"></px:PXNumberEdit>
            <px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit34" DataField="TotalWeight"></px:PXNumberEdit>
            <px:PXNumberEdit Enabled="False" runat="server" ID="CstPXNumberEdit14" DataField="TotalVolume"></px:PXNumberEdit>
        <px:PXNumberEdit CommitChanges="True" Enabled="False" runat="server" ID="CstPXNumberEdit1" DataField="TotalLCAmount" ></px:PXNumberEdit>
<px:PXNumberEdit CommitChanges="True" runat="server" ID="CstigcmTotalDutyAmount1" DataField="TotalDutyAmount" Enabled="False" ></px:PXNumberEdit>
        <px:PXNumberEdit CommitChanges="True" runat="server" ID="CstPXNumberEdit8" DataField="TotalTariffAmount" Enabled="False" ></px:PXNumberEdit>
	<px:PXNumberEdit runat="server" ID="CstPXNumberEdit107" DataField="ContainerVolume" ></px:PXNumberEdit></Template>
        
    
	<ClientEvents  ></ClientEvents></px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab Height="150px" DataMember="CurrentDocument" ID="tab" runat="server" Width="100%" DataSourceID="ds" AllowAutoHide="false">
        <Items>
            <px:PXTabItem Text="  Details">
                <Template>
                    <px:PXGrid AllowPaging="False" KeepPosition="True" AdjustPageSize="Auto" SyncPosition="True" Width="100%" DataSourceID="ds" SkinID="DetailsInTab" runat="server" ID="grid">
                        <Levels>
                            <px:PXGridLevel DataMember="LandedCostLines">
                                <Columns>
                                    <px:PXGridColumn LinkCommand="viewOrder" CommitChanges="True" DataField="PONbr" Width="120"></px:PXGridColumn>
	<px:PXGridColumn DataField="POOrderDesc" Width="220" ></px:PXGridColumn>
	<px:PXGridColumn Type="CheckBox" CommitChanges="True" DataField="Cancelled" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="VendorID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="VendorRefNbr" Width="180" ></px:PXGridColumn>
                                    <px:PXGridColumn DataField="BranchID" Width="70"></px:PXGridColumn>
                                    <px:PXGridColumn LinkCommand="viewInventory" AutoCallBack="True" CommitChanges="True" DataField="InventoryID" Width="170"></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="UPCCode" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InTransitSiteLocation" Width="140" CommitChanges="True" ></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="SiteID" Width="120" ></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="DestSiteID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="LocationID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OriginCountry" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="DestinationCountry" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="LotSerialNbr" Width="200" ></px:PXGridColumn>
                                    <px:PXGridColumn DataField="Descr" Width="200"></px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="True" DataField="OrderQty" Width="85"></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="ContainerQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="QtyOnContainers" Width="100" ></px:PXGridColumn>
                                    <px:PXGridColumn DataField="InTransitQty" Width="100" ></px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptQty" Width="85"></px:PXGridColumn>
    <px:PXGridColumn DataField="ReceiptNbr" Width="140" LinkCommand="viewReceipt" ></px:PXGridColumn>
    <px:PXGridColumn DataField="ReturnQty" Width="100" ></px:PXGridColumn>
    <px:PXGridColumn LinkCommand="viewReturn" DataField="ReturnNbr" Width="140" ></px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="True" DataField="UnitCost" Width="85"></px:PXGridColumn>
	<px:PXGridColumn DataField="CuryID" Width="70" CommitChanges="True" ></px:PXGridColumn>
	<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="GSPEligible" Width="60" CommitChanges="True" ></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="CustomClassificationNbr" Width="120" ></px:PXGridColumn>
    <px:PXGridColumn CommitChanges="True" DataField="DutyAmt" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" DataField="Tariff" Width="100" ></px:PXGridColumn>

                                    <px:PXGridColumn DataField="DiscPct" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="CuryDiscAmt" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="CuryDiscAmtVisible" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="CuryExtCost" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="ContainerNbr" Width="70"></px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="True" DataField="UOM" Width="50"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="UnitWeight" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="UnitVolume" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="True" DataField="DollarsAllocated" Width="150"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="ExpireDate" Width="120"></px:PXGridColumn>
	<px:PXGridColumn DataField="FactoryReadyDate" Width="90" ></px:PXGridColumn>
	<px:PXGridColumn DataField="UsrIGCMInvoiceNbr" Width="280" ></px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="True" DataField="POLineNbr" Width="70"></px:PXGridColumn>
	<px:PXGridColumn DataField="APBillRefNbr" Width="180" ></px:PXGridColumn>
	<px:PXGridColumn LinkCommand="viewAPBill" DataField="APBillNbr" Width="140" ></px:PXGridColumn></Columns>
                                <RowTemplate>
	<px:PXSegmentMask runat="server" ID="CstPXSegmentMask1" DataField="LocationID" AutoRefresh="True" ></px:PXSegmentMask>
	<px:PXSelector AutoRefresh="True" runat="server" ID="CstPXSelector1" DataField="UOM" ></px:PXSelector>
	<px:PXSegmentMask CommitChanges="True" AutoRefresh="True" runat="server" ID="igcmSiteIDSegmentMask2" DataField="SiteID" ></px:PXSegmentMask>
	<px:PXSelector AutoRefresh="True" runat="server" ID="CstPXSelector2" DataField="InTransitSiteLocation" ></px:PXSelector></RowTemplate>
                            </px:PXGridLevel>
                        </Levels>
                        <ActionBar>
                            <CustomItems>
                                <px:PXToolBarButton Text="Line Details" Key="cmdLS" CommandName="IGCMLandedCostLineSplittingExtension_ShowSplits" CommandSourceID="ds" DependOnGrid="grid"></px:PXToolBarButton>
                                <px:PXToolBarSeperator></px:PXToolBarSeperator>
                                <px:PXToolBarButton Key="cmdPO" Text="Add Order" CommandSourceID="ds" CommandName="AddPOOrder"></px:PXToolBarButton>
                                <px:PXToolBarButton Key="cmdAddPOLine" Text="Add Order Line" CommandSourceID="ds" CommandName="AddPOOrderLine"></px:PXToolBarButton>
	<px:PXToolBarButton CommandName="AddSOTransfer" Text="Add Transfer" CommandSourceID="ds" Key="SOTransfers" ></px:PXToolBarButton>
                                <px:PXToolBarSeperator></px:PXToolBarSeperator>
                                <px:PXToolBarButton Key="cmdViewPOOrder" Text="View Order">
                                    <AutoCallBack Command="ViewOrder" Target="ds"></AutoCallBack>
                                </px:PXToolBarButton>
                                <px:PXToolBarButton DependOnGrid="grid" CommandSourceID="ds" Key="cmdOverrideTallyQty" CommandName="OverrideTallyQty" Text="Override Tally Qty"></px:PXToolBarButton>
	<px:PXToolBarButton CommandSourceID="ds" DependOnGrid="grid" Key="cmdInHistory" CommandName="INDocuments" Text="View IN History" ></px:PXToolBarButton>
	<px:PXToolBarButton  DependOnGrid="grid" CommandName="AllocateSOLines"  Text="Allocate" CommandSourceID="ds" Key="allocateSOLines" >
		<AutoCallBack Enabled="True" ></AutoCallBack></px:PXToolBarButton>
	<px:PXToolBarButton Text="Import Po Container" CommandName="ImportPoContainer" CommandSourceID="ds" Key="UplodedPoContainer" ></px:PXToolBarButton></CustomItems>
                            <Actions>
                                <AddNew Enabled="False" ToolBarVisible="Top"></AddNew>
                            
	<Upload Enabled="True" ></Upload></Actions>
                        </ActionBar>
                        <Mode AllowUpload="True" AllowFormEdit="False"></Mode>
                        <CallbackCommands>
                            <Refresh CommitChanges="True"></Refresh>
                        
	<InitRow CommitChanges="True" ></InitRow></CallbackCommands>
                        <AutoCallBack>
                            <Behavior CommitChanges="True"></Behavior>
                        </AutoCallBack>
                        <AutoSize Enabled="True" Container="Parent"></AutoSize>
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Vendor / Customer Info">
                <Template>
                    <px:PXLayoutRule runat="server" ID="CstPXLayoutRule27" StartGroup="True" GroupCaption="Vendor Address"></px:PXLayoutRule>
                    <px:PXFormView runat="server" CaptionVisible="False" RenderStyle="Simple" ID="CstFormView28" DataMember="Remit_Contact">
                        <Template>
                            <px:PXLayoutRule runat="server" ID="CstPXLayoutRule47" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXTextEdit runat="server" DataField="FullName" ID="CstPXTextEdit31"></px:PXTextEdit>
                            <px:PXTextEdit runat="server" DataField="Salutation" ID="CstPXTextEdit34"></px:PXTextEdit>
                            <px:PXTextEdit runat="server" DataField="Phone1" ID="CstPXTextEdit33"></px:PXTextEdit>
                            <px:PXTextEdit runat="server" DataField="Email" ID="CstPXTextEdit30"></px:PXTextEdit>
                        </Template>
                    </px:PXFormView>
                    <px:PXFormView runat="server" CaptionVisible="False" RenderStyle="Simple" ID="CstFormView29" DataMember="Remit_Address">
                        <Template>
                            <px:PXLayoutRule LabelsWidth="SM" ControlSize="XM" runat="server" ID="CstPXLayoutRule35" StartColumn="True"></px:PXLayoutRule>
                            <px:PXTextEdit runat="server" DataField="AddressLine1" ID="CstPXTextEdit35"></px:PXTextEdit>
                            <px:PXTextEdit runat="server" DataField="AddressLine2" ID="CstPXTextEdit36"></px:PXTextEdit>
                            <px:PXTextEdit runat="server" DataField="City" ID="CstPXTextEdit37"></px:PXTextEdit>
                            <px:PXSelector runat="server" DataField="CountryID" ID="CstPXSelector38"></px:PXSelector>
                            <px:PXSelector runat="server" DataField="State" ID="CstPXSelector42"></px:PXSelector>
                            <px:PXTextEdit runat="server" DataField="PostalCode" ID="CstPXTextEdit41"></px:PXTextEdit>
                        </Template>
                    </px:PXFormView>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule17" StartColumn="True" ></px:PXLayoutRule>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule6" StartGroup="True" ></px:PXLayoutRule>
	<px:PXFormView runat="server" ID="CstFormView7" DataMember="CurrentDocument" Caption="Customer Info" CaptionVisible="True">
		<Template>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule23" StartGroup="True" LabelsWidth="SM" ></px:PXLayoutRule>
			<px:PXSegmentMask runat="server" ID="CstPXSegmentMask8" DataField="CustomerID" ></px:PXSegmentMask>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit9" DataField="CustomerOrderNbr" ></px:PXTextEdit>
			<px:PXSelector runat="server" ID="CstPXSelector10" DataField="CustomerPaymentStatusID" ></px:PXSelector></Template></px:PXFormView></Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Dates">
                <Template>
                    <px:PXLayoutRule  LabelsWidth="XM" runat="server" ID="CstPXLayoutRule41" StartColumn="True"></px:PXLayoutRule>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit43" DataField="ExpectedDepartureDate"></px:PXDateTimeEdit>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit42" DataField="ExpectedArrivalDate"></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="edExpectedArrivalSearateDate" DataField="ExpectedArrivalSearateDate" CommitChanges="True" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit25" DataField="FactoryReadyDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit31" DataField="UsrIGCMFactoryPickupDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit34" DataField="UsrIGCMOnBoardDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit29" DataField="UsrIGCMContainerLoadingDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit28" DataField="UsrIGCMCargoReadyDate" ></px:PXDateTimeEdit>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit44" DataField="PaymentDueDate"></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit15" DataField="ShipmentWindowStartDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit14" DataField="ShipmentWindowEndDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit26" DataField="GCCDate" ></px:PXDateTimeEdit>
                    <px:PXLayoutRule  LabelsWidth="XM" runat="server" ID="CstPXLayoutRule18" StartColumn="True"></px:PXLayoutRule>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit46" DataField="ActualDepartureDate"></px:PXDateTimeEdit>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit45" DataField="ActualArrivalDate"></px:PXDateTimeEdit>
                    <px:PXTextEdit runat="server" ID="CstPXTextEdit51" DataField="CustomsEntryNbr"></px:PXTextEdit>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit50" DataField="CustomsEntryDate"></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit30" DataField="UsrIGCMExpCustomsClearanceDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit5" DataField="DrayageAppointmentDate_Date" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit TimeMode="True" runat="server" ID="CstPXDateTimeEdit24" DataField="DrayageAppointmentDate_Time" ></px:PXDateTimeEdit>
                    <px:PXLayoutRule  LabelsWidth="XM" runat="server" ID="CstPXLayoutRule19" StartColumn="True"></px:PXLayoutRule>
                    <px:PXTextEdit runat="server" ID="CstPXTextEdit47" DataField="DeliveryOrderNbr"></px:PXTextEdit>
	<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit20" DataField="DeliveryOrderDate_Date" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit TimeMode="True" CommitChanges="True" runat="server" ID="CstPXDateTimeEdit21" DataField="DeliveryOrderDate_Time" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit32" DataField="UsrIGCMFinalDeliveryDate" ></px:PXDateTimeEdit>
                    <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit49" DataField="LastFreeDate"></px:PXDateTimeEdit>
                    <px:PXTextEdit runat="server" ID="CstPXTextEdit52" DataField="BrokerInvoiceNbr"></px:PXTextEdit>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit11" DataField="MainReferenceInvoice" ></px:PXTextEdit>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit12" DataField="SecondaryInvoice" ></px:PXTextEdit>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit16" DataField="UsrIGCMBillOfLadingNumber" ></px:PXTextEdit>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit6" DataField="SCACNumber" />
	<px:PXNumberEdit runat="server" ID="CstPXNumberEdit13" DataField="EstimatedFreight" ></px:PXNumberEdit></Template>
            </px:PXTabItem>
            <px:PXTabItem  Text="Landed Costs">
                <Template>
                    <px:PXGrid DataSourceID="ds" SyncPosition="True" runat="server" SkinID="Details" Width="100%" ID="lcGrid" AdjustPageSize="Auto">
                        <AutoSize Enabled="True"></AutoSize>
                        <Levels>
                            <px:PXGridLevel DataMember="LandedCosts">
                                <Columns>
                                    <px:PXGridColumn LinkCommand="viewLandedCostCode" AutoCallBack="True" DataField="LandedCostCodeID" Width="120" CommitChanges="True"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="LandedCostCode__Descr" Width="200"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="DollarsPayable" Width="100" CommitChanges="True"></px:PXGridColumn>
	<px:PXGridColumn DataField="CuryID" Width="70" ></px:PXGridColumn>
                                    <px:PXGridColumn DataField="InvoiceNbr" Width="160"></px:PXGridColumn>
                                    <px:PXGridColumn LinkCommand="viewVendor" CommitChanges="True" DataField="VendorID" Width="120"></px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="True" DataField="VendorLocationID" Width="70"></px:PXGridColumn>
	<px:PXGridColumn DataField="PrepaymentMethodID" Width="120" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ExtRefNbr" Width="180" ></px:PXGridColumn>
	<px:PXGridColumn DataField="CashAccountID" Width="120" ></px:PXGridColumn>
	<px:PXGridColumn LinkCommand="ViewPrepayment" DataField="PrepaymentNbr" Width="140" ></px:PXGridColumn></Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <Mode AllowFormEdit="False"></Mode>
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
	<px:PXTabItem Text="Vessel Info">
		<Template>
			<px:PXGrid runat="server" ID="CstPXVesselInfo" AdjustPageSize="Auto" SkinID="Details" Width="100%">
				<Levels>
					<px:PXGridLevel DataMember="VesselInfo" >
						<Columns>
							<px:PXGridColumn DataField="MMSI" Width="108" ></px:PXGridColumn>
							<px:PXGridColumn DataField="Timestamp" Width="90" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ETA" Width="90" ></px:PXGridColumn>
							<px:PXGridColumn DataField="DESTINATION" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="DEPARTURE" Width="90" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LASTPORT" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LASTCOUNTRY" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LATITUDE" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LONGITUDE" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="COURSE" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="SPEED" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="HEADING" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="NAVSTAT" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="IMO" Width="120" ></px:PXGridColumn>
							<px:PXGridColumn DataField="NAME" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="CALLSIGN" Width="120" ></px:PXGridColumn>
							<px:PXGridColumn DataField="TYPE" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="A" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="B" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="C" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="D" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="DRAUGHT" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LOCODE" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ETAAIS" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="SRC" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ZONE" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ECA" Width="60" ></px:PXGridColumn>
							<px:PXGridColumn DataField="DISTANCEREMAINING" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ETAPREDICTED" Width="90" ></px:PXGridColumn>
							<px:PXGridColumn DataField="FLAG" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="TYPESTRING" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="BUILT" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="BUILDER" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="OWNER" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="MANAGER" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="CLASS" Width="280" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LENGTH" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="BEAM" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="MAXDRAUGHT" Width="100" ></px:PXGridColumn>
							<px:PXGridColumn DataField="GT" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="NT" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="DWT" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="TEU" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="CRUDE" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="VOYAGELOCODE" Width="120" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
				<AutoSize Enabled="True" ></AutoSize>
				<ActionBar>
					<CustomItems>
						<px:PXToolBarButton Text="Update Vessel Info">
							<AutoCallBack Command="UpdateVesselInfo" Target="ds" ></AutoCallBack></px:PXToolBarButton>
						<px:PXToolBarButton Text="Clear" >
							<AutoCallBack Command="ClearVesselInfo" Target="ds" ></AutoCallBack></px:PXToolBarButton>
						<px:PXToolBarButton Text="Show Vessel Location" >
							<AutoCallBack Command="ShowVesselLocation" ></AutoCallBack>
							<AutoCallBack Target="ds" ></AutoCallBack></px:PXToolBarButton></CustomItems></ActionBar></px:PXGrid></Template></px:PXTabItem>
	<px:PXTabItem Text="Searates Info">
		<Template>
			<px:PXGrid runat="server" ID="CstPXSearateInfo" AdjustPageSize="Auto" SkinID="Details" Width="100%" SyncPosition="True">
				<Levels>
					<px:PXGridLevel DataMember="IGSFCMSearateInfo">
						<Columns>
							<px:PXGridColumn DataField="VesselName" Width="280" />
							<px:PXGridColumn DataField="VesselMMSI" Width="108" />
							<px:PXGridColumn DataField="VesselImo" Width="120" />
							<px:PXGridColumn DataField="VesselFlag" Width="70" />
							<px:PXGridColumn DataField="VesselCallSign" Width="120" />
							<px:PXGridColumn DataField="ContainerNumber" Width="140" />
							<px:PXGridColumn DataField="ContainerIsoCode" Width="140" />
							<px:PXGridColumn DataField="PrepolLocationName" Width="220" />
							<px:PXGridColumn DataField="PrepolDate" Width="90" />
							<px:PXGridColumn DataField="PrepolActual" Width="60" Type="CheckBox" TextAlign="Center" />
							<px:PXGridColumn DataField="PolLocationName" Width="220" />
							<px:PXGridColumn DataField="PolDate" Width="90" />
							<px:PXGridColumn DataField="PolActual" Width="60" Type="CheckBox" TextAlign="Center" />
							<px:PXGridColumn DataField="PodLocationName" Width="220" />
							<px:PXGridColumn DataField="PodDate" Width="90" />
							<px:PXGridColumn DataField="PodActual" Width="60" Type="CheckBox" TextAlign="Center" />
							<px:PXGridColumn DataField="PostpodLocationName" Width="220" />
							<px:PXGridColumn DataField="PostpodDate" Width="90" />
							<px:PXGridColumn DataField="PostpodActual" Width="60" Type="CheckBox" TextAlign="Center" /></Columns></px:PXGridLevel></Levels>
				<AutoSize Enabled="True" />
				<ActionBar>
					<CustomItems>
						<px:PXToolBarButton Text="Update Searates Info">
							<AutoCallBack Target="ds" Command="UpdateSearateInfo" /></px:PXToolBarButton>
						<px:PXToolBarButton Text="Clear">
							<AutoCallBack Target="ds" Command="ClearSearateInfo" /></px:PXToolBarButton>
						<px:PXToolBarButton Text="Show Events">
							<AutoCallBack Target="ds" Command="ShowSearateEventsInfo" /></px:PXToolBarButton></CustomItems></ActionBar></px:PXGrid></Template></px:PXTabItem>
<px:PXTabItem Text="Expeditors Info" >
		<Template>
			<px:PXGrid SyncPosition="True" SkinID="Inquire" Width="100%" AdjustPageSize="Auto" runat="server" ID="CstPXExpeditorInfo">
				<Levels>
					<px:PXGridLevel DataMember="IGCMExpeditorInfoView" >
						<Columns>
							<px:PXGridColumn DataField="InstanceNo" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ContainerNumber" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="ShipmentNumber" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="LastUpdateTime" Width="130px" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
				<AutoSize Enabled="True" ></AutoSize>
				<ActionBar>
					<CustomItems>
						<px:PXToolBarButton Text="Update Expeditors Info" >
							<AutoCallBack Target="ds" Command="UpdateExpeditorInfo" ></AutoCallBack></px:PXToolBarButton>
						<px:PXToolBarButton Text="Clear">
							<AutoCallBack Command="ClearExpeditorInfo" Target="ds" ></AutoCallBack></px:PXToolBarButton>
                                                <px:PXToolBarButton Text="Show Container Info" >
							<AutoCallBack Command="ShowContainerInfo" ></AutoCallBack>
							<AutoCallBack Target="ds" ></AutoCallBack></px:PXToolBarButton>
						<px:PXToolBarButton Text="Show Shipment Info" >
							<AutoCallBack Command="ShowShipmentInfo" ></AutoCallBack>
							<AutoCallBack Target="ds" ></AutoCallBack></px:PXToolBarButton></CustomItems></ActionBar></px:PXGrid></Template></px:PXTabItem></Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
    </px:PXTab>
    <px:PXSmartPanel AutoReload="True" AutoRepaint="True" ID="PanelAddPOLine" runat="server" Height="676px" HideAfterAction="True" Style="z-index: 108;" Width="1020px"
        Key="poLinesSelection" Caption="Add Purchase Order Line" CaptionVisible="True" LoadOnDemand="true" ShowAfterLoad="true"
        AutoCallBack-Command="Refresh" AutoCallBack-Enabled="True" AutoCallBack-Target="frmPOFilter">
        <px:PXFormView ID="frmPOFilter" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="filter" Caption="PO Selection"
            SkinID="Transparent" CaptionVisible="false">
            <CallbackCommands>
                <Refresh RepaintControls="None" RepaintControlsIDs="gridOL"></Refresh>
                <Save RepaintControls="None" RepaintControlsIDs="gridOL"></Save>
            </CallbackCommands>
            <Template>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM"></px:PXLayoutRule>
                <px:PXDropDown CommitChanges="True" ID="edOrderType" runat="server" AllowNull="False" DataField="OrderType" SelectedIndex="2"></px:PXDropDown>
                <px:PXLayoutRule ID="PXLayoutRule30" runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM"></px:PXLayoutRule>
                <px:PXSelector CommitChanges="True" ID="edOrderNbr" runat="server" DataField="OrderNbr" AutoRefresh="True">
	<AutoCallBack ></AutoCallBack>
	<AutoCallBack Target="poLinesSelection" ></AutoCallBack></px:PXSelector>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit7" DataField="UsrIGCMVendorRef" CommitChanges="True" /></Template>
        </px:PXFormView>
        <px:PXGrid ID="gridOL" runat="server" Height="600px" Width="100%" DataSourceID="ds" AutoAdjustColumns="true" AdjustPageSize="Auto" SkinID="Inquire">
            <AutoSize Container="Parent" Enabled="true"></AutoSize>
            <Levels>
                <px:PXGridLevel DataMember="poLinesSelection">
                    <Columns>
                        <px:PXGridColumn DataField="Selected" Width="60px" Type="CheckBox" AllowCheckAll="True" AutoCallBack="True" TextAlign="Center"></px:PXGridColumn>
                        <px:PXGridColumn AllowUpdate="False" DataField="OrderNbr" DisplayFormat="&gt;CCCCCCCCCCCCCCC" Label="Order Nbr." Width="140px"></px:PXGridColumn>
                        <px:PXGridColumn DataField="LineNbr" TextAlign="Right" Visible="False"></px:PXGridColumn>
                        <px:PXGridColumn DataField="VendorID" DisplayFormat="&gt;AAAAAAAAAA" Label="Vendor" Width="100px"></px:PXGridColumn>
	<px:PXGridColumn DataField="UsrIGCMVendorRef" Width="180" ></px:PXGridColumn>
                        <px:PXGridColumn DataField="InventoryID" DisplayFormat="&gt;AAAAAAAAAA" Width="100px"></px:PXGridColumn>
                        <px:PXGridColumn DataField="TranDesc" Width="200px"></px:PXGridColumn>
	<px:PXGridColumn CommitChanges="True" Type="CheckBox" AllowCheckAll="True" DataField="UsrIGCMShippedFull" Width="60" ></px:PXGridColumn>
                        <px:PXGridColumn DataField="OrderQty" Width="100px" TextAlign="Right"></px:PXGridColumn>
                        <px:PXGridColumn DataField="ReceivedQty" Width="108px" TextAlign="Right"></px:PXGridColumn>
	<px:PXGridColumn DataField="UsrIGCMQtyOnContainers" Width="100" ></px:PXGridColumn>
                        <px:PXGridColumn DataField="LeftToReceiveQty" Width="108px" TextAlign="Right"></px:PXGridColumn>
                        <px:PXGridColumn DataField="UOM" Width="63px" DisplayFormat="&gt;aaaaaa"></px:PXGridColumn>
                        <px:PXGridColumn AllowNull="False" DataField="LineType" Width="90px"></px:PXGridColumn>
                        <px:PXGridColumn DataField="PromisedDate" TextAlign="Left" Width="80px"></px:PXGridColumn></Columns>
                </px:PXGridLevel>
            </Levels>
            <AutoSize Enabled="true"></AutoSize>
            <CallbackCommands>
                <Save RepaintControls="None"></Save>
            </CallbackCommands>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel3" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton1" runat="server" Text="Add" SyncVisible="false">
                <AutoCallBack Command="AddPOOrderLine2" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton DialogResult="OK" ID="PXButton2" runat="server" Text="Add & Close">
	<AutoCallBack  ></AutoCallBack></px:PXButton>
            <px:PXButton ID="PXButton9" runat="server" DialogResult="Cancel" Text="Cancel"></px:PXButton>
        </px:PXPanel></px:PXSmartPanel>
    <px:PXSmartPanel AutoReload="True" ID="PanelAddPO" runat="server" Style="z-index: 108; height: 600px;" Width="960px" Caption="Add Purchase Order"
        CaptionVisible="True" LoadOnDemand="true" Key="openOrders" AutoCallBack-Command="Refresh" AutoCallBack-Enabled="True"
        AutoCallBack-Target="frmOrderFilter1" AutoRepaint="True">
        <px:PXFormView ID="frmOrderFilter1" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="filter"
            Caption="PO Selection" SkinID="Transparent" CaptionVisible="False">
            <Template>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM"></px:PXLayoutRule>
                <px:PXDropDown  CommitChanges="True" ID="edOrderType" runat="server" DataField="OrderType" SelectedIndex="2"></px:PXDropDown>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
	<px:PXSegmentMask AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSegmentMask2" DataField="VendorID" ></px:PXSegmentMask>
	<px:PXSegmentMask CommitChanges="True" AutoRefresh="True" runat="server" ID="CstPXSegmentMask3" DataField="VendorLocationID" ></px:PXSegmentMask></Template>
        
	<CallbackCommands>
		<Refresh  ></Refresh></CallbackCommands></px:PXFormView>
        <px:PXGrid AutoRepaint="True" SyncPosition="True" SkinID="Inquire" AdjustPageSize="Auto" ID="grdOpenOrders" runat="server" Height="500px" Width="100%" DataSourceID="ds" Style="border-width: 1px 0px;"
            AutoAdjustColumns="true">
            <AutoSize Enabled="true"></AutoSize>
            <Levels>
                <px:PXGridLevel DataMember="openOrders">
                    <Columns>
                        <px:PXGridColumn AllowCheckAll="True" AllowNull="False" AutoCallBack="True" DataField="Selected" TextAlign="Center" Type="CheckBox"
                            Width="60px">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="OrderType"></px:PXGridColumn>
                        <px:PXGridColumn Width="200px" DataField="OrderNbr"></px:PXGridColumn>
	<px:PXGridColumn TextAlign="Center" DataField="UsrIGCMShippedFull" Width="60" Type="CheckBox" AllowCheckAll="True" ></px:PXGridColumn>
                        <px:PXGridColumn DataField="OrderDate" Width="90px"></px:PXGridColumn>
                        <px:PXGridColumn AllowNull="False" AllowUpdate="False" DataField="Status"></px:PXGridColumn>
                        <px:PXGridColumn AllowNull="False" AllowUpdate="False" DataField="CuryOrderTotal" Width="100px" TextAlign="Right"></px:PXGridColumn>
                        <px:PXGridColumn DataField="VendorRefNbr"></px:PXGridColumn>
                        <px:PXGridColumn DataField="OrderDesc" Width="200px"></px:PXGridColumn></Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel4" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton8" runat="server" Text="Add" SyncVisible="false">
                <AutoCallBack Command="AddPOOrder2" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="Add & Close">
	<AutoCallBack Target="ds" ></AutoCallBack></px:PXButton>
            <px:PXButton ID="PXButton4" runat="server" DialogResult="No" Text="Cancel"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
<px:PXSmartPanel AutoReload="True" ID="PanelAddTransfer" runat="server" Style="z-index: 108; height: 600px;" Width="960px" Caption="Add SO Transfer"
        CaptionVisible="True" LoadOnDemand="true" Key="SOTransfers" AutoCallBack-Command="Refresh" AutoCallBack-Enabled="True"
        AutoCallBack-Target="grdOpenAvailTransfers" AutoRepaint="True">
        <px:PXFormView ID="frmTransferFilter" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="sOTransferFilter"
             SkinID="Transparent" CaptionVisible="False">
            <Template>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule87" StartColumn="True" ></px:PXLayoutRule>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule89" StartGroup="True" GroupCaption="Date Interval" ></px:PXLayoutRule>
	<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit91" DataField="StartDate" ></px:PXDateTimeEdit>
	<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit90" DataField="EndDate" ></px:PXDateTimeEdit>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule88" StartColumn="True" ></px:PXLayoutRule>
	<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector83" DataField="DestinationSiteID" ></px:PXSelector>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM"></px:PXLayoutRule>
	<px:PXNumberEdit CommitChanges="True" runat="server" ID="CstPXNumberEdit95" DataField="Priority" ></px:PXNumberEdit></Template>
        
	<CallbackCommands>
		<Refresh ></Refresh></CallbackCommands></px:PXFormView>
        <px:PXGrid KeepPosition="True" BatchUpdate="True" AutoRepaint="True" SyncPosition="True" SkinID="Inquire" AdjustPageSize="Auto" ID="grdOpenAvailTransfers" runat="server" Height="500px" Width="100%" DataSourceID="ds" Style="border-width: 1px 0px;"
            AutoAdjustColumns="true">
            <AutoSize Enabled="true"></AutoSize>
<Levels>
<px:PXGridLevel DataMember="SOTransfers">

	<Columns>
		<px:PXGridColumn CommitChanges="True" Type="CheckBox" AllowCheckAll="True" DataField="Selected" Width="60" ></px:PXGridColumn>
		<px:PXGridColumn DataField="OrderType" Width="70" ></px:PXGridColumn>
		<px:PXGridColumn LinkCommand="viewSOOrder" DataField="OrderNbr" Width="140" ></px:PXGridColumn>
		<px:PXGridColumn LinkCommand="viewSOShipment" DataField="ShipmentNbr" Width="140" ></px:PXGridColumn>
		<px:PXGridColumn DataField="ShipDate" Width="90" ></px:PXGridColumn>
		<px:PXGridColumn DataField="ShipmentQty" Width="100" ></px:PXGridColumn>
		<px:PXGridColumn CommitChanges="True" DataField="SOOrder__DestinationSiteID" Width="140" ></px:PXGridColumn>
		<px:PXGridColumn CommitChanges="True" LinkCommand="viewINTransfer" DataField="InvtRefNbr" Width="140" ></px:PXGridColumn>
		<px:PXGridColumn CommitChanges="True" DataField="SOOrder__Priority" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel>
</Levels>
        </px:PXGrid>

        <px:PXPanel ID="PXTransferPanel" runat="server" SkinID="Buttons">
	<px:PXButton runat="server" ID="CstButton96" Text="ADD">
		<AutoCallBack Command="addSOTransfer2" Target="ds" ></AutoCallBack></px:PXButton>
	<px:PXButton runat="server" ID="CstButton74" Text="ADD &amp; Close" DialogResult="OK" ></px:PXButton>
	<px:PXButton runat="server" ID="CstButton75" DialogResult="No" Text="Cancel" ></px:PXButton></px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel ID="PanelLS" runat="server" Style="z-index: 108;" Width="764px" Height="360px" Caption="Line Details" CaptionVisible="True" Key="IGCMLandedCostLineSplittingExtension_lsselect" 
AutoCallBack-Command="Refresh" AutoCallBack-Target="optform" DesignView="Content" TabIndex="3200">
        <px:PXFormView ID="optform" runat="server" Width="100%" CaptionVisible="False" DataMember="IGCMLandedCostLineSplittingExtension_LotSerOptions" DataSourceID="ds" SkinID="Transparent" TabIndex="-3236">
            <Template>
                <px:PXLayoutRule ID="PXLayoutRule26" runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                <px:PXNumberEdit ID="edUnassignedQty" runat="server" DataField="UnassignedQty" Enabled="False"></px:PXNumberEdit>
                <px:PXNumberEdit ID="edQty" runat="server" DataField="Qty">
                    <AutoCallBack>
                        <Behavior CommitChanges="True"></Behavior>
                    </AutoCallBack>
                </px:PXNumberEdit>
                <px:PXLayoutRule ID="PXLayoutRule27" runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                <px:PXMaskEdit ID="edStartNumVal" runat="server" DataField="StartNumVal"></px:PXMaskEdit>
                <px:PXButton ID="btnGenerate" runat="server" Text="Generate" Height="20px" CommandName="IGCMLandedCostLineSplittingExtension_GenerateNumbers" CommandSourceID="ds"></px:PXButton>
            </Template>
     <Parameters>
      <px:PXSyncGridParam ControlID="grid" ></px:PXSyncGridParam>
    </Parameters>
        </px:PXFormView>
        <px:PXGrid ID="grid2" runat="server" Width="100%" AutoAdjustColumns="True" DataSourceID="ds" Style="border-width: 1px 0px; left: 0px; top: 0px; height: 192px;" SyncPosition="true" AllowFilter="true" SkinID="Details">           
            <Parameters>
                <px:PXSyncGridParam ControlID="grid"></px:PXSyncGridParam>
            </Parameters>
            <Levels>
                <px:PXGridLevel DataMember="splits">
                    <Columns>
                        <px:PXGridColumn DataField="InventoryID" Width="108px"></px:PXGridColumn>
	<px:PXGridColumn DataField="SiteID" Width="140" ></px:PXGridColumn>
                        <px:PXGridColumn DataField="SubItemID" Width="108px"></px:PXGridColumn>
                        <px:PXGridColumn DataField="LocationID" AllowShowHide="Server" Width="108px"></px:PXGridColumn>
	<px:PXGridColumn DataField="InTransitLocation" Width="140" />
                        <px:PXGridColumn  DataField="LotSerialNbr"  Width="108px" AutoCallBack="True"></px:PXGridColumn>
                        <px:PXGridColumn  DataField="Qty" Width="108px" TextAlign="Right"></px:PXGridColumn>
                        <px:PXGridColumn DataField="UOM" Width="108px"></px:PXGridColumn>
                        <px:PXGridColumn DataField="ExpireDate" Width="90px"></px:PXGridColumn></Columns>
                    <RowTemplate>
                        <px:PXLayoutRule ID="PXLayoutRule28" runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM"></px:PXLayoutRule>
                        <px:PXSegmentMask ID="edSubItemID2" runat="server" DataField="SubItemID" AutoRefresh="true"></px:PXSegmentMask>
                        <px:PXSegmentMask ID="edLocationID2" runat="server" DataField="LocationID" AutoRefresh="true">
                            <Parameters>
                                <px:PXControlParam ControlID="grid2" Name="IGCMPOLandedCostLineSplit.siteID" PropertyName="DataValues[&quot;SiteID&quot;]" Type="String"></px:PXControlParam>
                                <px:PXControlParam ControlID="grid2" Name="IGCMPOLandedCostLineSplit.inventoryID" PropertyName="DataValues[&quot;InventoryID&quot;]" Type="String"></px:PXControlParam>
                                <px:PXControlParam ControlID="grid2" Name="IGCMPOLandedCostLineSplit.subItemID" PropertyName="DataValues[&quot;SubItemID&quot;]" Type="String"></px:PXControlParam>
                            </Parameters>
                        </px:PXSegmentMask>
                        <px:PXNumberEdit ID="edQty2" runat="server" DataField="Qty"></px:PXNumberEdit>
                        <px:PXSelector ID="edUOM2" runat="server" DataField="UOM" AutoRefresh="true">
                            <Parameters>
                                <px:PXControlParam ControlID="grid" Name="IGCMPOLandedCostLine.inventoryID" PropertyName="DataValues[&quot;InventoryID&quot;]" Type="String"></px:PXControlParam>
                            </Parameters>
                        </px:PXSelector>
                        <px:PXSelector ID="edLotSerialNbr2" runat="server" DataField="LotSerialNbr" AutoRefresh="true">
                            <Parameters>
                                <px:PXControlParam ControlID="grid2" Name="IGCMPOLandedCostLineSplit.inventoryID" PropertyName="DataValues[&quot;InventoryID&quot;]" Type="String"></px:PXControlParam>
                                <px:PXControlParam ControlID="grid2" Name="IGCMPOLandedCostLineSplit.subItemID" PropertyName="DataValues[&quot;SubItemID&quot;]" Type="String"></px:PXControlParam>
                                <px:PXControlParam ControlID="grid2" Name="IGCMPOLandedCostLineSplit.locationID" PropertyName="DataValues[&quot;LocationID&quot;]" Type="String"></px:PXControlParam>
                            </Parameters>
                        </px:PXSelector>
                        <px:PXDateTimeEdit ID="edExpireDate2" runat="server" DataField="ExpireDate"></px:PXDateTimeEdit>
                    </RowTemplate>
                </px:PXGridLevel>
            </Levels>
            <AutoSize Enabled="true"></AutoSize>
	<Mode InitNewRow="True" ></Mode></px:PXGrid>
        <px:PXPanel ID="PXPanel2" runat="server" SkinID="Buttons">
            <px:PXButton ID="btnSave" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
	<px:PXSmartPanel CommandSourceID="ds" Width="1000px" Position="CenterWindow" runat="server" ID="CstSmartPanel23" AutoReload="True" AutoRepaint="True" CaptionVisible="True" Caption="Inventory Transactions History" Key="INDocumentsView" AcceptButtonID="CstButton26">
		<px:PXGrid SkinID="Inquire" AllowPaging="True" Width="100%" runat="server" ID="CstPXGrid24" SyncPosition="True" SyncPositionWithGraph="True" KeepPosition="True" Height="400" AutoAdjustColumns="False" NoteIndicator="False" FilesIndicator="False">
			<ContentLayout AutoSizeControls="True" ></ContentLayout>
			<Levels>
				<px:PXGridLevel DataMember="LineINDocuments">
					<Columns>
						<px:PXGridColumn DataField="TranType" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="RefNbr" Width="120" LinkCommand="ViewInDocument" ></px:PXGridColumn>
						<px:PXGridColumn DataField="InventoryID" Width="150" ></px:PXGridColumn>
						<px:PXGridColumn DataField="TranDesc" Width="200" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SiteID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LocationID" Width="120" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LotSerialNbr" Width="200" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UOM" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="Qty" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UnitCost" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="TranCost" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="ExpireDate" Width="120" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid>
		<px:PXPanel runat="server" ID="CstPanel25" SkinId="Buttons">
			<px:PXButton runat="server" ID="CstButton26" Text="Ok" DialogResult="OK" AlignLeft="False" ></px:PXButton></px:PXPanel></px:PXSmartPanel>
	<px:PXSmartPanel ShowAfterLoad="True" CloseButtonDialogResult="OK" AutoCallBack-ActiveBehavior="True" AutoCallBack-Behavior-PostData="Container" AutoCallBack-Behavior-CommitChanges="True" AutoCallBack-Behavior-RepaintControls="All"   AutoCallBack-Enabled="True"  AutoCallBack-Target="gridAllocations" AutoCallBack-Command="Refresh"  LoadOnDemand="True" CaptionVisible="True" runat="server" ID="pnlSOAllocationLines" Caption="Allocate To SO" Key="Allocations" AutoReload="True" AutoRepaint="True" Height="800px" Width="960px"  >
		<px:PXFormView runat="server" ID="fvSOOrderLineFilter" Caption="Show SO Allocations Filter" CaptionVisible="False" SkinID="Transparent" Width="100%" DataSourceID="ds" DataMember="SOAllocationfilter" >
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule33" StartColumn="True" ControlSize="XM" LabelsWidth="S" ></px:PXLayoutRule>
				<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector35" DataField="OrderType" >
					<AutoCallBack Target="" Command="" ></AutoCallBack>
					<AutoCallBack Enabled="True" ></AutoCallBack>
					<AutoCallBack Target="gridAllocations" ></AutoCallBack></px:PXSelector>
				<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector34" DataField="OrderNbr" ></px:PXSelector>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule46" StartColumn="True" ></px:PXLayoutRule>
				<px:PXNumberEdit runat="server" ID="CstPXNumberEdit47" DataField="AvailableQtyForAllocation" CommitChanges="True" ></px:PXNumberEdit></Template>
			<CallbackCommands>
				<Refresh  ></Refresh></CallbackCommands></px:PXFormView>
		<px:PXGrid KeepPosition="True" BatchUpdate="True" Height="200px" Width="100%" AutoRepaint="True" SkinID="Inquire" SyncPosition="True" AdjustPageSize="Auto" AutoAdjustColumns="True" runat="server" ID="gridSOAllocationLines" DataSourceID="ds">
			<Levels>
				<px:PXGridLevel DataMember="SOAllocationLines" >
					<Columns>
						<px:PXGridColumn AllowCheckAll="True" CommitChanges="True" Type="CheckBox" DataField="UsrIGCMIsSelected" Width="60" ></px:PXGridColumn>
						<px:PXGridColumn DataField="OrderType" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="OrderNbr" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn TextAlign="Center" DataField="LineNbr" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn TextAlign="Center" DataField="InventoryID" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn TextAlign="Center" DataField="OrderQty" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn TextAlign="Center" DataField="UOM" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SOOrder__Status" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="CustomerID" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="OrderDate" Width="90" ></px:PXGridColumn>
						<px:PXGridColumn DataField="RequestDate" Width="90" ></px:PXGridColumn>
						<px:PXGridColumn DataField="UnitPrice" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
			<AutoCallBack Target="gridAllocations" Enabled="True" Command="Refresh"  >
				<Behavior CommitChanges="true" ></Behavior></AutoCallBack>
			<AutoCallBack Command="Refresh" ></AutoCallBack>
			<Layout HighlightMode="Both" ></Layout>
			<AutoSize Enabled="True" ></AutoSize>
			<Mode AllowAddNew="False" ></Mode></px:PXGrid>
		<px:PXGrid SyncPositionWithGraph="True"   BatchUpdate="True"  Height="200px" KeepPosition="True" SyncPosition="True"  runat="server" ID="gridAllocations" SkinID="Inquire" Width="100%" DataSourceID="ds" >
			<Levels>
				<px:PXGridLevel DataMember="Allocations" >
					<Columns>
						<px:PXGridColumn AllowCheckAll="True" Type="CheckBox" DataField="Selected" Width="70" CommitChanges="True" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LandedCostNbr" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="LCLineNbr" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="OrderType" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="OrderNbr" Width="100" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SOLineNbr" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="SOLineOrderQty" Width="70" ></px:PXGridColumn>
						<px:PXGridColumn DataField="AllocatedQty" Width="70" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>			
			
			
			<AutoCallBack Target="gridSOAllocationLines"  Enabled="True" Command="Refresh" >
													<Behavior CommitChanges="True" ></Behavior></AutoCallBack>
			<AutoCallBack Enabled="False" ></AutoCallBack>
			
			
			<CallbackCommands>
				<Refresh CommitChanges="True" ></Refresh></CallbackCommands>
			<Mode AllowAddNew="False" ></Mode></px:PXGrid>
		<px:PXPanel SkinID="Buttons" runat="server" ID="CstPanel40">
			<px:PXButton Target="gridAllocations" runat="server" ID="CstButton43" Text="Apply Allocations" >
				<AutoCallBack Command="ApplyAllocations" Target="ds" ></AutoCallBack>
				<AutoCallBack Command="ApplyAllocations" ></AutoCallBack></px:PXButton>
			<px:PXButton runat="server" ID="CstButton48" Text="UnAllocate Line">
				<AutoCallBack Target="ds" Command="UnAllocateLine" ></AutoCallBack></px:PXButton></px:PXPanel></px:PXSmartPanel>
	<px:PXSmartPanel runat="server" ID="SmartPanelIGSFCMSearateLineInfo" Caption="Events Information" CaptionVisible="True" Key="IGSFCMSearateEventsInfo" LoadOnDemand="False" Width="60%" AllowResize="False" AutoReload="True" AutoRepaint="True" CloseButtonDialogResult="No" Position="CenterWindow" DesignView="Content" AutoCallBack-Command="Refresh">
		<px:PXFormView runat="server" ID="formIGSFCMSearateLineInfo" Caption="Events Information" DataMember="IGSFCMSearateLineInfo" SkinID="Transparent" Width="100%" DataSourceID="ds">
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule4" StartRow="True" />
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule7" StartColumn="True" />
				<px:PXGrid runat="server" ID="gridIGSFCMSearateEventsInfo" Caption="Events Information" Height="220px" SkinID="Inquire" Width="100%" AllowFilter="False" DataSourceID="ds" FilesIndicator="False" NoteIndicator="False" CaptionVisible="False">
					<Levels>
						<px:PXGridLevel DataMember="IGSFCMSearateEventsInfo">
							<Columns>
								<px:PXGridColumn DataField="Description" Width="130" />
								<px:PXGridColumn DataField="Status" Width="70" />
								<px:PXGridColumn DataField="EventDate" Width="90" />
								<px:PXGridColumn DataField="EventActual" Width="60" Type="CheckBox" TextAlign="Center" />
								<px:PXGridColumn DataField="Type" Width="80" />
								<px:PXGridColumn DataField="Voyage" Width="80" />
								<px:PXGridColumn DataField="LocationName" Width="120" />
								<px:PXGridColumn DataField="LocationState" Width="150" />
								<px:PXGridColumn DataField="LocationCountryCode" Width="70" />
								<px:PXGridColumn DataField="LocationCountry" Width="150" />
								<px:PXGridColumn DataField="LocationLocode" Width="80" />
								<px:PXGridColumn DataField="LocationLat" Width="100" />
								<px:PXGridColumn DataField="LocationLng" Width="100" /></Columns></px:PXGridLevel></Levels></px:PXGrid>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule5" StartRow="True" />
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule6" StartColumn="True" />
				<px:PXPanel runat="server" ID="panelIGSFCMSearateEventsInfo" SkinID="Buttons">
					<px:PXButton runat="server" ID="btnIGSFCMSearateOK" DialogResult="OK" Text="OK" /></px:PXPanel></Template></px:PXFormView></px:PXSmartPanel>
<px:PXSmartPanel AutoCallBack-Command="Refresh" DesignView="Content" Position="CenterWindow" AllowResize="False" AutoReload="True" AutoRepaint="True" CloseButtonDialogResult="No" LoadOnDemand="False" Width="65%" Key="IGCMExpeditorContainerInfoView" runat="server" ID="SmartPanelIGCMExpeditorContainerLineInfo" Caption="Container Information" CaptionVisible="True">
		<px:PXFormView DataSourceID="ds" Width="100%" SkinID="Transparent" Caption="Container Information" DataMember="IGCMExpeditorContainerInfoView" runat="server" ID="formIGCMExpeditorContainerInfo" >
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule18" StartColumn="True" ></px:PXLayoutRule>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit22" DataField="InstanceNo" ></px:PXTextEdit>
				<px:PXMaskEdit runat="server" ID="CstPXMaskEdit21" DataField="ContainerNumber" ></px:PXMaskEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit28" DataField="OriginName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit30" DataField="OriginCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit25" DataField="DestinationName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit24" DataField="DestinationCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit26" DataField="Mode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit23" DataField="Carrier" ></px:PXTextEdit>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule19" StartColumn="True" ></px:PXLayoutRule>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit106" DataField="Size" />
				<px:PXTextEdit runat="server" ID="CstPXTextEdit36" DataField="MoveType" ></px:PXTextEdit>
				<px:PXDateTimeEdit Size="182px" runat="server" ID="CstPXDateTimeEdit33" DataField="ActualDepartureDate" ></px:PXDateTimeEdit>
				<px:PXDateTimeEdit Size="182px" runat="server" ID="CstPXDateTimeEdit35" DataField="EstimatedDepartureDate" ></px:PXDateTimeEdit>
				<px:PXDateTimeEdit Size="182px" runat="server" ID="CstPXDateTimeEdit32" DataField="ActualArrivalDate" ></px:PXDateTimeEdit>
				<px:PXDateTimeEdit Size="182px" runat="server" ID="CstPXDateTimeEdit34" DataField="EstimatedArrivalDate" ></px:PXDateTimeEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit37" DataField="Vessel" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit38" DataField="VoyageNumber" ></px:PXTextEdit>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule20" StartColumn="True" ></px:PXLayoutRule>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit41" DataField="SealNumber" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit93" DataField="PackagesValue" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit39" DataField="PackagesUnits" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit95" DataField="WeightValue" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit44" DataField="WeightUnits" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit94" DataField="VolumeValue" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit42" DataField="VolumeUnits" ></px:PXTextEdit></Template></px:PXFormView>
		<px:PXTab SyncPosition="True" DataMember="" runat="server" ID="tabContainerInfo">
			<Items>
				<px:PXTabItem Text="Container Events" >
					<Template>
						<px:PXGrid Height="200px" SyncPosition="True" DataSourceID="ds" SkinID="Inquire" Width="100%" runat="server" ID="CstPXExpeditorContainerEvents">
							<Levels>
								<px:PXGridLevel DataMember="IGCMExpeditorContainerEventsView" >
									<Columns>
										<px:PXGridColumn DataField="InstanceNo" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Code" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Description" Width="280" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Time" Width="90" ></px:PXGridColumn>
										<px:PXGridColumn DataField="OriginName" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="OriginCode" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="DestinationName" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="DestinationCode" Width="70" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
							
							</px:PXGrid></Template></px:PXTabItem>
				<px:PXTabItem Text="Container Lines" >
					<Template>
						<px:PXGrid Height="200px" SyncPosition="True" DataSourceID="ds" Width="100%" SkinID="Inquire" runat="server" ID="CstPXExpeditorContainerLines">
							<Levels>
								<px:PXGridLevel DataMember="IGCMExpeditorContainerLinesView" >
									<Columns>
										<px:PXGridColumn DataField="WeightValue" Width="100" ></px:PXGridColumn>
										<px:PXGridColumn DataField="WeightUnits" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="VolumeValue" Width="100" ></px:PXGridColumn>
										<px:PXGridColumn DataField="VolumeUnits" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="ShipmentNumber" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="QuantityValue" Width="100" ></px:PXGridColumn>
										<px:PXGridColumn DataField="QuantityUnits" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="PackagesValue" Width="100" ></px:PXGridColumn>
										<px:PXGridColumn DataField="PackagesUnits" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="LoadSequence" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="InstanceNo" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="BillOfLadingNumber" Width="140" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem></Items></px:PXTab>
		<px:PXPanel SkinID="Buttons" runat="server" ID="panelIGCMExpeditorContainerInfo" >
			<px:PXButton runat="server" ID="btnIGCMExpeditorContainerOK" DialogResult="OK" Text="OK" ></px:PXButton></px:PXPanel></px:PXSmartPanel>
	<px:PXSmartPanel AutoCallBack-Command="Refresh" DesignView="Content" CloseButtonDialogResult="No" Position="CenterWindow" AllowResize="False" AutoReload="True" AutoRepaint="True" Key="IGCMExpeditorShipmentInfoView" CaptionVisible="True" LoadOnDemand="False" Width="65%" runat="server" ID="SmartPanelIGCMExpeditorShipmentLineInfo" Caption="Shipment Information">
		<px:PXFormView SkinID="Transparent" Width="100%" DataSourceID="ds" Caption="Shipment Information" runat="server" ID="CstIGCMExpeditorShipmentInfoViewForm" DataMember="IGCMExpeditorShipmentInfoView">
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule52" StartColumn="True" ></px:PXLayoutRule>
				<px:PXMaskEdit runat="server" ID="CstPXMaskEdit89" DataField="ShipmentNumber" ></px:PXMaskEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit64" DataField="Status" ></px:PXTextEdit>
				<px:PXDateTimeEdit Size="182px" runat="server" ID="CstPXDateTimeEdit60" DataField="LastUpdateTime" ></px:PXDateTimeEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit63" DataField="OriginName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit62" DataField="OriginCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit59" DataField="DestinationName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit58" DataField="DestinationCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit97" DataField="DeliveryName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit96" DataField="DeliveryCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit99" DataField="LoadingName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit98" DataField="LoadingCode" ></px:PXTextEdit>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule53" StartColumn="True" ></px:PXLayoutRule>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit103" DataField="UnladingName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit102" DataField="UnladingCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit101" DataField="ClearanceName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit100" DataField="ClearanceCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit66" DataField="Mode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit70" DataField="Vessel" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit90" DataField="QuantityValue" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit67" DataField="QuantityUnits" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit91" DataField="WeightValue" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit71" DataField="WeightUnits" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit92" DataField="VolumeValue" ></px:PXTextEdit>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule54" StartColumn="True" ></px:PXLayoutRule>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit81" DataField="VolumeUnits" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit76" DataField="CarrierName" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit75" DataField="CarrierCode" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit77" DataField="Consignee" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit104" DataField="ActualReceiptTimesInvoiceNumber" />
				<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit105" DataField="ActualReceiptTimesTime" />
				<px:PXTextEdit runat="server" ID="CstPXTextEdit78" DataField="GoodsDesc" ></px:PXTextEdit>
				<px:PXTextEdit runat="server" ID="CstPXTextEdit80" DataField="SecurityFilingParty" ></px:PXTextEdit>
				<px:PXCheckBox Enabled="False" runat="server" ID="CstPXCheckBox79" DataField="Hazardous" ></px:PXCheckBox></Template></px:PXFormView>
		<px:PXTab SyncPosition="True" runat="server" ID="tabShipmentInfo">
			<Items>
				<px:PXTabItem Text="Shipment Documents" >
					<Template>
						<px:PXGrid Height="200px" DataSourceID="ds" SyncPosition="True" SkinID="Inquire" Width="100%" runat="server" ID="CstPXExpeditorShipmentDocuments">
							<Levels>
								<px:PXGridLevel DataMember="IGCMExpeditorShipmentDocView" >
									<Columns>
										<px:PXGridColumn DataField="DocumentType" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Group" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Label" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="FileSize" Width="140" ></px:PXGridColumn>
										<px:PXGridColumn DataField="NumberOfPages" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="DownloadCallbackUrl" Width="280" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem>
				<px:PXTabItem Text="Shipment Events" >
					<Template>
						<px:PXGrid Height="200px" DataSourceID="ds" SyncPosition="True" SkinID="Inquire" Width="100%" runat="server" ID="CstPXExpeditorShipmentEvents">
							<Levels>
								<px:PXGridLevel DataMember="IGCMExpeditorShipmentEventsView" >
									<Columns>
										<px:PXGridColumn DataField="Description" Width="280" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Time" Width="90" ></px:PXGridColumn>
										<px:PXGridColumn DataField="OriginName" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="OriginCode" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="DestinationName" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="DestinationCode" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Remarks" Width="280" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Invoice" Width="70" ></px:PXGridColumn>
										<px:PXGridColumn DataField="Code" Width="70" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem>
				<px:PXTabItem Text="Shipment References" >
					<Template>
						<px:PXGrid Height="200px" runat="server" ID="CstPXExpeditorShipmentReferences" SkinID="Inquire" Width="100%" DataSourceID="ds" SyncPosition="True">
							<Levels>
								<px:PXGridLevel DataMember="IGCMExpeditorShipmentReferencesView" >
									<Columns>
										<px:PXGridColumn DataField="RefType" Width="180" ></px:PXGridColumn>
										<px:PXGridColumn DataField="RefNumber" Width="180" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem></Items> 
           </px:PXTab>
		<px:PXPanel SkinID="Buttons" runat="server" ID="panelIGCMExpeditorShipmentInfo">
			<px:PXButton Text="OK" DialogResult="OK" runat="server" ID="btnIGCMExpeditorShipmentOK" ></px:PXButton></px:PXPanel></px:PXSmartPanel>
<px:PXUploadDialog Visible="True" Height="60px" RenderLinkTextBox="False" AllowedFileTypes=".xlsx" AutoSaveFile="False" Caption="Import Container Line Details" RenderCheckIn="False" RenderComment="False" 
                                                           RenderLink="False" Width="400px" SessionKey="UplodedPoContainer" runat="server" ID="CstUploadDialog" Key="CurrentDocument" ></px:PXUploadDialog></asp:Content>