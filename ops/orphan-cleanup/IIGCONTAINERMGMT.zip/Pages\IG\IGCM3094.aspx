<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3094.aspx.cs" Inherits="Page_IGCM3094" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMShippingContainerEntry"
        PrimaryView="Container"
        >
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="addShipment" Visible="False" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Visible="False" Name="addSOShipLine" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="addPackage" Visible="False" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="viewSOShipment" Visible="False" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="complete" Visible="True" CommitChanges="True" ></px:PXDSCallbackCommand>
			<px:PXDSCallbackCommand Name="preparePOReceipt" /></CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Container" Width="100%" Height="" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector24" DataField="ShippingContNbr" ></px:PXSelector>
			<px:PXDropDown CommitChanges="True" runat="server" ID="CstPXDropDown6" DataField="Status" ></px:PXDropDown>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox3" DataField="Hold" ></px:PXCheckBox>
			<px:PXSelector AllowEdit="True" runat="server" ID="CstPXSelector109" DataField="POReceiptNbr" ></px:PXSelector>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector Required="False" CommitChanges="True" runat="server" ID="CstPXSelector21" DataField="CustomerID" ></px:PXSelector>
			<px:PXSelector Required="True" runat="server" ID="CstPXSelector106" DataField="DestinationSiteID" CommitChanges="True" ></px:PXSelector>
			<px:PXDropDown Required="True" CommitChanges="True" runat="server" ID="CstPXDropDown103" DataField="ShipmentType" ></px:PXDropDown>
			<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit4" DataField="ShippingContainerDate" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit22" DataField="ContainerNbr" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule30" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector31" DataField="ContainerStatusID" ></px:PXSelector>
			<px:PXNumberEdit CommitChanges="True" Enabled="False" runat="server" ID="CstPXNumberEdit114" DataField="OrderQty" ></px:PXNumberEdit>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit11" DataField="TotalWeight" ></px:PXNumberEdit>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit10" DataField="TotalVolume" ></px:PXNumberEdit></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab DataMember="CurrentDocument" ID="tab" runat="server" Width="100%" Height="" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="Details">
				<Template>
					<px:PXGrid SkinID="DetailsInTab" Width="100%" AdjustPageSize="Auto" AllowPaging="True" Height="" runat="server" ID="grid">
						<Levels>
							<px:PXGridLevel DataMember="ShippingContainerLines" >
								<Columns>
									<px:PXGridColumn LinkCommand="viewSOShipment" DataField="ShipmentNbr" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ShipLineNbr" Width="80" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ShipmentDate" Width="90" ></px:PXGridColumn>
									<px:PXGridColumn LinkCommand="viewInventory" DataField="InventoryID" Width="80" ></px:PXGridColumn>
									<px:PXGridColumn DataField="SiteID" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="LocationID" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="LotSerialNbr" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="TranDesc" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="OrderedQty" Width="80" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="ContainerQty" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="QtyOnContainers" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="OpenQty" Width="80" ></px:PXGridColumn>
									<px:PXGridColumn DataField="UnitWeight" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="UnitVolume" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ExtWeight" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ExtVolume" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ExpireDate" Width="90" ></px:PXGridColumn>
									<px:PXGridColumn DisplayMode="Value" Type="CheckBox" DataField="Confirmed" Width="120" ></px:PXGridColumn>
									<px:PXGridColumn DisplayMode="Value" Type="CheckBox" DataField="Released" Width="80" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
						<AutoSize Enabled="True" ></AutoSize>
						<ActionBar>
							<CustomItems>
								<px:PXToolBarButton DependOnGrid="grdShipments" Key="" PopupPanel="" Text="Add Shipment" CommandName="" >
									<AutoCallBack Target="ds" Command="AddShipment" ></AutoCallBack>
									<PopupCommand Command="" ></PopupCommand></px:PXToolBarButton>
								<px:PXToolBarButton DependOnGrid="grdShipments" PopupPanel="" Text="Add Ship. Line">
									<AutoCallBack Target="ds" Command="AddSOShipLine" ></AutoCallBack></px:PXToolBarButton></CustomItems>
							<Actions>
								<AddNew MenuVisible="False" /></Actions>
							<Actions>
								<AddNew ToolBarVisible="False" /></Actions></ActionBar></px:PXGrid></Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Packages">
				<Template>
                                         <px:PXGrid SkinID="DetailsInTab" Width="100%" AdjustPageSize="Auto" AllowPaging="True" runat="server" ID="packagesGrid">
						<Levels>
							<px:PXGridLevel DataMember="packages">
					 
								<Columns>
									<px:PXGridColumn Type="CheckBox" DataField="Confirmed" Width="90" ></px:PXGridColumn>
									<px:PXGridColumn DataField="BoxID" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="PackageType" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ShipmentNbr" Width="140" ></px:PXGridColumn>
														<px:PXGridColumn DataField="PackLineNbr" Width="70" ></px:PXGridColumn>
														<px:PXGridColumn DataField="Description" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Weight" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="WeightUOM" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="DeclaredValue" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="COD" Width="100" ></px:PXGridColumn>
														<px:PXGridColumn DataField="TrackNumber" Width="212" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
	<AutoSize Enabled="True" ></AutoSize>
	<ActionBar>
		<CustomItems>
			<px:PXToolBarButton Text="Add Package" DependOnGrid="grdPackages">
				<AutoCallBack Target="ds" Command="AddPackage" ></AutoCallBack></px:PXToolBarButton></CustomItems></ActionBar></px:PXGrid>
                                </Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Dates" >
				<Template>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule45" StartColumn="True" ></px:PXLayoutRule>
					<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit56" DataField="ExpectedDepartureDate" ></px:PXDateTimeEdit>
					<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit49" DataField="ActualDepartureDate" ></px:PXDateTimeEdit>
					<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit57" DataField="PaymentDueDate" ></px:PXDateTimeEdit>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule46" StartColumn="True" ></px:PXLayoutRule>
					<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit55" DataField="ExpectedArrivalDate" ></px:PXDateTimeEdit>
					<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit48" DataField="ActualArrivalDate" ></px:PXDateTimeEdit>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit52" DataField="CustomsEntryNbr" ></px:PXTextEdit>
					<px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit51" DataField="CustomsEntryDate" ></px:PXDateTimeEdit>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule58" StartColumn="True" ></px:PXLayoutRule>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit54" DataField="DeliveryOrderNbr" ></px:PXTextEdit>
					<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit53" DataField="DeliveryOrderDate" ></px:PXDateTimeEdit>
					<px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit50" DataField="CompletionDate" ></px:PXDateTimeEdit>
					<px:PXGrid runat="server" ID="CstPXGrid63">
						<Levels>
							<px:PXGridLevel ></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem>
			<px:PXTabItem RepaintOnDemand="False" VisibleExp="" Text="Customer Info" >
				<Template>
					<px:PXFormView DataMember="ContactInfo" runat="server" ID="ContactInfo" >
						<Template>
							<px:PXLayoutRule GroupCaption="Contact Info" runat="server" ID="CstPXLayoutRule84" StartGroup="True" ></px:PXLayoutRule>
							<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox100" DataField="OverrideContact" ></px:PXCheckBox>
							<px:PXTextEdit Enabled="" runat="server" ID="CstPXTextEdit88" DataField="FullName" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit85" DataField="Attention" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit90" DataField="Phone1" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit86" DataField="Email" ></px:PXTextEdit></Template></px:PXFormView>
					<px:PXFormView runat="server" ID="AddressInfo" DataMember="AddressInfo" >
						<Template>
							<px:PXLayoutRule GroupCaption="Address Info" runat="server" ID="CstPXLayoutRule91" StartGroup="True" ></px:PXLayoutRule>
							<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox101" DataField="OverrideAddress" ></px:PXCheckBox>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit92" DataField="AddressLine1" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit93" DataField="AddressLine2" ></px:PXTextEdit>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit94" DataField="City" ></px:PXTextEdit>
							<px:PXSelector runat="server" ID="CstPXSelector95" DataField="CountryID" ></px:PXSelector>
							<px:PXSelector runat="server" ID="CstPXSelector97" DataField="State" ></px:PXSelector>
							<px:PXTextEdit runat="server" ID="CstPXTextEdit96" DataField="PostalCode" ></px:PXTextEdit></Template></px:PXFormView></Template></px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
	</px:PXTab>


<px:PXSmartPanel AutoReload="True" ID="PanelAddShipment" runat="server" Style="z-index: 108; height: 600px;" Width="960px" Caption="Add Shipment"
  CaptionVisible="True" LoadOnDemand="true" Key="shipments" AutoCallBack-Command="Refresh" AutoCallBack-Enabled="True"
  AutoCallBack-Target="frmOrderFilter1" AutoRepaint="True">
  <px:PXGrid AutoRepaint="True" SyncPosition="True" SkinID="Inquire" AdjustPageSize="Auto" ID="grdShipments" runat="server" Height="500px" Width="100%" DataSourceID="ds" Style="border-width: 1px 0px;"
    AutoAdjustColumns="true">
    <AutoSize Enabled="true"></AutoSize>
    <Levels>
      <px:PXGridLevel DataMember="shipments">
        <Columns>
          <px:PXGridColumn AllowCheckAll="True" AllowNull="False" AutoCallBack="True" DataField="Selected" TextAlign="Center" Type="CheckBox"
            Width="60px">
          </px:PXGridColumn>
          <px:PXGridColumn Width="200px" DataField="ShipmentNbr"></px:PXGridColumn>
	<px:PXGridColumn DataField="ShipmentType" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn Type="CheckBox" AllowCheckAll="True" DataField="UsrIGCMShippedFull" Width="60" ></px:PXGridColumn>
          <px:PXGridColumn Type="NotSet" AllowCheckAll="False" DataField="ShipDate" Width="90px"></px:PXGridColumn>
          <px:PXGridColumn DataField="CustomerID"></px:PXGridColumn>
          <px:PXGridColumn AllowNull="False" AllowUpdate="False" DataField="Status"></px:PXGridColumn>
          <px:PXGridColumn AllowNull="False" AllowUpdate="False" DataField="LineTotal" Width="100px" TextAlign="Right"></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
  </px:PXGrid>
  <px:PXPanel ID="PXPanel4" runat="server" SkinID="Buttons">
    <px:PXButton ID="PXButton8" runat="server" Text="Add" SyncVisible="false">
      <AutoCallBack Command="AddShipment2" Target="ds"></AutoCallBack>
    </px:PXButton>
    <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="Add & Close"></px:PXButton>
    <px:PXButton ID="PXButton4" runat="server" DialogResult="No" Text="Cancel"></px:PXButton>
  </px:PXPanel>
  </px:PXSmartPanel>

<px:PXSmartPanel CallBackMode-CommitChanges="True" AutoCallBack-Behavior-CommitChanges="True" AutoReload="" AutoRepaint="" ID="PanelAddShipLine" runat="server" Height="370px" HideAfterAction="false" Style="z-index: 108;" Width="1020px"
  Key="ShipLine" Caption="Add Ship. Line" CaptionVisible="True" LoadOnDemand="" ShowAfterLoad="true">
  <px:PXGrid AutoRepaint="True" SyncPosition="True" ID="gridOL" runat="server" Height="304px" Width="100%" DataSourceID="ds" AutoAdjustColumns="true" AdjustPageSize="Auto" SkinID="Details">
    <AutoSize Enabled="true"></AutoSize>
    <Levels>
      <px:PXGridLevel DataMember="shipLine">
        <Columns>
	<px:PXGridColumn CommitChanges="True" DataField="UsrIGCMSelected" Width="60" Type="CheckBox" AllowCheckAll="True" ></px:PXGridColumn>
	<px:PXGridColumn DataField="SOShipment__ShipmentNbr" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="SOShipment__ShipmentType" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn AllowCheckAll="True" Type="CheckBox" DataField="UsrIGCMShippedFull" Width="60" ></px:PXGridColumn>
	<px:PXGridColumn DataField="UsrIGCMCustomerID" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn Visible="" DataField="LineNbr" Width="70" ></px:PXGridColumn>
          <px:PXGridColumn DataField="InventoryID" DisplayFormat="&gt;AAAAAAAAAA" Width="100px"></px:PXGridColumn>
          <px:PXGridColumn DataField="TranDesc" Width="200px"></px:PXGridColumn>
          <px:PXGridColumn DataField="OrigOrderQty" Width="100px" TextAlign="Right"></px:PXGridColumn>
          <px:PXGridColumn DataField="ShippedQty" Width="108px" TextAlign="Right"></px:PXGridColumn>
	<px:PXGridColumn DataField="UsrIGCMQtyOnContainers" Width="100" ></px:PXGridColumn>
          <px:PXGridColumn DataField="UnassignedQty" Width="108px" TextAlign="Right"></px:PXGridColumn>
          <px:PXGridColumn DataField="UOM" Width="63px" DisplayFormat="&gt;aaaaaa"></px:PXGridColumn>
          <px:PXGridColumn DataField="ExpireDate" TextAlign="Left" Width="80px"></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Enabled="true"></AutoSize>
    <CallbackCommands>
    
	<Refresh CommitChanges="True" ></Refresh></CallbackCommands>
  
	<AutoCallBack>
		<Behavior CommitChanges="True" ></Behavior></AutoCallBack>
	<OnChangeCommand>
		<Behavior CommitChanges="True" ></Behavior></OnChangeCommand></px:PXGrid>
  <px:PXPanel ID="PXPanel3" runat="server" SkinID="Buttons">
    <px:PXButton DialogResult="None" ID="PXButton1" runat="server" Text="Add" SyncVisible="false">
      <AutoCallBack Command="AddSOShipLine2" Target="ds"></AutoCallBack>
    </px:PXButton>
    <px:PXButton ID="PXButton2" runat="server" DialogResult="OK" Text="Add & Close"></px:PXButton>
    <px:PXButton ID="PXButton9" runat="server" DialogResult="No" Text="Cancel"></px:PXButton>
  </px:PXPanel>
  </px:PXSmartPanel>

<px:PXSmartPanel AutoReload="True" ID="PanelAddPackage" runat="server" Style="z-index: 108; height: 600px;" Width="960px" Caption="Add Package"
  CaptionVisible="True" LoadOnDemand="true" Key="packDetails" AutoCallBack-Command="Refresh" AutoCallBack-Enabled="True"
  AutoRepaint="True">
  <px:PXGrid KeepPosition="True" AutoRepaint="True" SyncPosition="True" SkinID="Inquire" AdjustPageSize="Auto" ID="grdPackages" runat="server" Height="500px" Width="100%" DataSourceID="ds" Style="border-width: 1px 0px;"
    AutoAdjustColumns="true">
    <AutoSize Container="Parent" MinHeight="200" Enabled="true"></AutoSize>
    <Levels>
      <px:PXGridLevel DataMember="packDetails">
        <Columns>
	<px:PXGridColumn DataField="UsrIGCMSelected" Width="60" Type="CheckBox" AllowCheckAll="True" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="ShipmentNbr" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="SOShipment__ShipmentType" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="LineNbr" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="BoxID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" Type="CheckBox" DataField="Confirmed" Width="90" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="Description" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="TrackNumber" Width="220" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="Weight" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn AllowUpdate="False" DataField="WeightUOM" Width="70" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
  
	<ActionBar>
		<CustomItems ></CustomItems></ActionBar>
	<AutoCallBack Command="Refresh" ></AutoCallBack>
	<AutoCallBack Target="CstPXGrid110" ></AutoCallBack></px:PXGrid>
	<px:PXGrid runat="server" ID="CstPXGrid110" Caption="Ship. Lines" AdjustPageSize="Auto" AllowPaging="True" CaptionVisible="True" Height="150" SkinID="Inquire" Width="100%" DataSourceID="ds" SyncPosition="True" KeepPosition="True">
		<Levels>
			<px:PXGridLevel DataMember="contShipLineUnbound" >
				<Columns>
					<px:PXGridColumn DataField="ShipmentNbr" Width="140" ></px:PXGridColumn>
					<px:PXGridColumn DataField="ShipContLineNbr" Width="70" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
					<px:PXGridColumn DataField="UOM" Width="140" ></px:PXGridColumn>
					<px:PXGridColumn DataField="Qty" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
		<AutoSize Container="Parent" />
		<AutoSize Enabled="True" /></px:PXGrid>
  <px:PXPanel ID="PXPanel5" runat="server" SkinID="Buttons">
    <px:PXButton ID="PXButton10" runat="server" Text="Attach Lines To Package" SyncVisible="false">
      <AutoCallBack Command="AttachLinesToPackage" Target="ds"></AutoCallBack>
    </px:PXButton>
    <px:PXButton ID="PXButton5" runat="server" DialogResult="OK" Text="Add & Close"></px:PXButton>
    <px:PXButton ID="PXButton6" runat="server" DialogResult="No" Text="Cancel"></px:PXButton></px:PXPanel></px:PXSmartPanel>

<px:PXSmartPanel Height="700" AutoReload="True" ID="PanelAttachLine" runat="server" Style="z-index: 108; height: 600px;" Width="960px" Caption="Attach Line to Package"
  CaptionVisible="True" LoadOnDemand="true" Key="shipLineS" AutoCallBack-Command="Refresh" AutoCallBack-Enabled="True"
  AutoRepaint="True">

	
  <px:PXGrid KeepPosition="True" Caption="Ship. Lines" CaptionVisible="True" AllowPaging="True" AutoRepaint="True" SyncPosition="True" SkinID="Inquire" AdjustPageSize="Auto" ID="grdAttachLines" runat="server" Height="250px" Width="100%" DataSourceID="ds" Style="border-width: 1px 0px;"
    AutoAdjustColumns="">
    <AutoSize Enabled="true"></AutoSize>
    <Levels>
      <px:PXGridLevel DataMember="shipLineS">
        <Columns>
	<px:PXGridColumn DataField="UsrIGCMSelected" Width="60" CommitChanges="True" Type="CheckBox" AllowCheckAll="True" ></px:PXGridColumn>
	<px:PXGridColumn DataField="SOShipment__ShipmentNbr" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="SOShipment__ShipmentType" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="SOShipment__CustomerID" Width="140" ></px:PXGridColumn>
	<px:PXGridColumn DataField="LineNbr" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
	<px:PXGridColumn DataField="TranDesc" Width="280" ></px:PXGridColumn>
	<px:PXGridColumn DataField="OrigOrderQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ShippedQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="UnassignedQty" Width="100" ></px:PXGridColumn>
	<px:PXGridColumn DataField="UOM" Width="72" ></px:PXGridColumn>
	<px:PXGridColumn DataField="ExpireDate" Width="90" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
<AutoCallBack Target="grdAttachPackage" Command="Refresh" Enabled="True" ></AutoCallBack>
  
	<ActionBar>
		<CustomItems ></CustomItems></ActionBar></px:PXGrid>
  <px:PXPanel ID="PXPanel6" runat="server" SkinID="Buttons">
    <px:PXButton DialogResult="OK" ID="PXButton11" runat="server" Text="Add" SyncVisible="false">
      <AutoCallBack Command="" Target="ds"></AutoCallBack>
    </px:PXButton>
    <px:PXButton ID="PXButton13" runat="server" DialogResult="No" Text="Cancel"></px:PXButton></px:PXPanel></px:PXSmartPanel></asp:Content>