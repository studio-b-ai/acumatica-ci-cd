<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM3091.aspx.cs" Inherits="Page_IGCM3091" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMFreightForwarderMaint"
        PrimaryView="FreightForwarder"
        >
    <CallbackCommands>

    </CallbackCommands>
  </px:PXDataSource></asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
  <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="FreightForwarder">
          <Columns>
        <px:PXGridColumn DataField="FreightForwarderID" Width="120" ></px:PXGridColumn>
        <px:PXGridColumn DataField="URL" Width="200" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    <ActionBar >
    </ActionBar>
  </px:PXGrid></asp:Content>