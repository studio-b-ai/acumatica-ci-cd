<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IGCM5098.aspx.cs" Inherits="Page_IGCM5098" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
  <px:PXDataSource PageLoadBehavior="PopulateSavedValues" ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="IGCM.IGCMPOPrintLandedCostProcess"
        PrimaryView="IIGFilter"
        >
    <CallbackCommands>
      <px:PXDSCallbackCommand CommitChanges="True" Visible="False" Name="Details" ></px:PXDSCallbackCommand></CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
  <px:PXFormView DefaultControlID="CstPXDropDown1" ID="form" runat="server" DataSourceID="ds" DataMember="IIGFilter" Width="100%" Height="" AllowAutoHide="false">
    <Template>
      <px:PXLayoutRule ControlSize="XM" LabelsWidth="S" ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
      <px:PXDropDown CommitChanges="True" Size="" runat="server" ID="CstPXDropDown1" DataField="Action" ></px:PXDropDown></Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
  <px:PXGrid SyncPosition="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="PrimaryInquire" AllowAutoHide="false">
    <Levels>
      <px:PXGridLevel DataMember="Records">
          <Columns>
        <px:PXGridColumn CommitChanges="True" AllowCheckAll="True" Type="CheckBox" AllowNull="False" TextAlign="Center" DataField="Selected" Width="30" ></px:PXGridColumn>
        <px:PXGridColumn DataField="LandedCostDate" Width="120" ></px:PXGridColumn>
        <px:PXGridColumn LinkCommand="Details" DataField="LandedCostNbr" Width="120" ></px:PXGridColumn>
        <px:PXGridColumn DataField="Status" Width="70" ></px:PXGridColumn>
        <px:PXGridColumn DataField="ContainerNbr" Width="140" />
        <px:PXGridColumn DataField="ContainerStatusID" Width="140" ></px:PXGridColumn>
        <px:PXGridColumn DataField="TotalAmount" Width="100" ></px:PXGridColumn>
        <px:PXGridColumn DataField="VendorID" Width="120" ></px:PXGridColumn></Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
    <ActionBar >
    </ActionBar>
  </px:PXGrid>
</asp:Content>